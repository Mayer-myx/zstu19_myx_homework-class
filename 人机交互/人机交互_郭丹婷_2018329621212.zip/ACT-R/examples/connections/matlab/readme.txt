Tested with MATLAB version R2017b

Run the simple.m script to add a command called "matlab-add" 
to ACT-R which takes two parameters and returns the sum of those
items if they are numbers.


Here's a sample call:

(evaluate-act-r-command "matlab-add" 3 4)