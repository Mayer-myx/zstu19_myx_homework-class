import sys
import os
import ACT.actr as actr
from PyQt5 import QtWidgets
from cogmod import Ui_SideBarDemo


class __Autonomy__(object):
    def __init__(self):
        self._buffer = ""

    def write(self, out_stream):
        self._buffer += out_stream


class HCI_TEST02(QtWidgets.QWidget, Ui_SideBarDemo):
    def __init__(self):
        super(HCI_TEST02, self).__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.run_model)

    def run_model(self):
        savedStdout = sys.stdout
        read = __Autonomy__()
        sys.stdout = read
        actr.load_act_r_code('D:/ACT-R/tutorial/unit1/count.lisp')
        actr.run(10)
        sys.stdout = savedStdout
        self.textBrowser.setText(read._buffer.__str__())
        self.textBrowser.ensureCursorVisible()
        # os.popen("taskkill /f /t /im act-r.exe")



if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)

    HCI_test02 = HCI_TEST02()
    HCI_test02.show()
    sys.exit(app.exec_())