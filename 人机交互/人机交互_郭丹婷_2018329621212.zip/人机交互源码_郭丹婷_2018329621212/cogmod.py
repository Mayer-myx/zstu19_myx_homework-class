# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'cogmod.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import procedure
import sys
import os
import ACT.actr as actr



class Ui_SideBarDemo(object):


    def jumpNew3(self):
        print("3")
        #MainWindow.close()
        #self.hide()
        self.sideWindow = QtWidgets.QWidget()
        self.sideBarUi = procedure.Ui_SideBarDemo()
        self.sideBarUi.setupUi(self.sideWindow)
        self.sideWindow.show()
        #MainWindow.show()

    def setupUi(self, SideBarDemo):
        SideBarDemo.setObjectName("SideBarDemo")
        SideBarDemo.resize(1024, 768)
        SideBarDemo.setStyleSheet("QWidget.SideBar {\n"
"    border-right: 1px solid rgb(170, 170, 170);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(50, 50, 50, 255),\n"
"        stop:1 rgba(150, 150, 150, 255));\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton {\n"
"    font-size: 13px;\n"
"    font-weight: normal;\n"
"    border: none;\n"
"    color: rgb(240,240,240);\n"
"\n"
"    padding-left:12px;\n"
"    padding-right: 12px;\n"
"    padding-top: 5px;\n"
"\n"
"    border-top: 1px dashed rgba(0,0,0,0);\n"
"    border-bottom: 1px dashed rgba(0,0,0,0);\n"
"    border-right: 1px dashed rgba(0,0,0,0);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton:hover {\n"
"    color: rgb(200, 200, 200);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[current=\"true\"] {\n"
"    border-top: 1px solid rgb(90,90,90);\n"
"    border-right: 1px solid rgb(200, 200, 200, 200);\n"
"    border-bottom: 1px solid rgb(90,90,90);\n"
"    color: black;\n"
"    background: qlineargradient(spread:pad,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(130, 130, 130, 255),\n"
"        stop:1 rgba(230, 230, 230, 255));\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}\n"
"\n"
"QWidget.SideBar .Separator {\n"
"    border: none;\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(10, 10, 10, 255),\n"
"        stop:1 rgba(220, 220, 220, 255));\n"
"}\n"
"\n"
"#content {\n"
"    border: none;\n"
"    border-left: 1px solid gray;\n"
"    background: rgba(0, 255, 0, 100);\n"
"}")
        SideBarDemo.setProperty("class", "")
        self.gridLayout = QtWidgets.QGridLayout(SideBarDemo)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setHorizontalSpacing(0)
        self.gridLayout.setVerticalSpacing(6)
        self.gridLayout.setObjectName("gridLayout")
        self.sideBar = QtWidgets.QWidget(SideBarDemo)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.sideBar.sizePolicy().hasHeightForWidth())
        self.sideBar.setSizePolicy(sizePolicy)
        self.sideBar.setMinimumSize(QtCore.QSize(90, 0))
        self.sideBar.setObjectName("sideBar")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.sideBar)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setSpacing(6)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.widget = QtWidgets.QWidget(self.sideBar)
        self.widget.setMinimumSize(QtCore.QSize(0, 1))
        self.widget.setMaximumSize(QtCore.QSize(16777215, 1))
        self.widget.setObjectName("widget")
        self.gridLayout_2.addWidget(self.widget, 4, 0, 1, 1)
        self.toolButton_4 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_4.sizePolicy().hasHeightForWidth())
        self.toolButton_4.setSizePolicy(sizePolicy)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/images/resources/button-3.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_4.setIcon(icon)
        self.toolButton_4.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_4.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_4.setObjectName("toolButton_4")
        self.gridLayout_2.addWidget(self.toolButton_4, 5, 0, 1, 1)
        self.toolButton_3 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_3.sizePolicy().hasHeightForWidth())
        self.toolButton_3.setSizePolicy(sizePolicy)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/images/resources/button-5.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_3.setIcon(icon1)
        self.toolButton_3.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_3.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_3.setObjectName("toolButton_3")
        self.gridLayout_2.addWidget(self.toolButton_3, 3, 0, 1, 1)
        self.toolButton_5 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_5.sizePolicy().hasHeightForWidth())
        self.toolButton_5.setSizePolicy(sizePolicy)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/images/resources/button-1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_5.setIcon(icon2)
        self.toolButton_5.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_5.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_5.setObjectName("toolButton_5")
        self.gridLayout_2.addWidget(self.toolButton_5, 6, 0, 1, 1)
        self.toolButton_1 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_1.sizePolicy().hasHeightForWidth())
        self.toolButton_1.setSizePolicy(sizePolicy)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(":/images/resources/button-2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_1.setIcon(icon3)
        self.toolButton_1.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_1.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_1.setObjectName("toolButton_1")
        self.gridLayout_2.addWidget(self.toolButton_1, 1, 0, 1, 1)
        self.toolButton_2 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_2.sizePolicy().hasHeightForWidth())
        self.toolButton_2.setSizePolicy(sizePolicy)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(":/images/resources/button-4.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_2.setIcon(icon4)
        self.toolButton_2.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_2.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_2.setObjectName("toolButton_2")
        self.gridLayout_2.addWidget(self.toolButton_2, 2, 0, 1, 1)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout_2.addItem(spacerItem, 7, 0, 1, 1)
        self.gridLayout.addWidget(self.sideBar, 0, 0, 1, 1)
        self.tabWidget = QtWidgets.QTabWidget(SideBarDemo)
        self.tabWidget.setObjectName("tabWidget")
        self.widget1 = QtWidgets.QWidget()
        self.widget1.setObjectName("widget1")
        self.pushButton_6 = QtWidgets.QPushButton(self.widget1)
        self.pushButton_6.setGeometry(QtCore.QRect(60, 660, 75, 23))
        self.pushButton_6.setObjectName("pushButton_6")
        self.textEdit = QtWidgets.QTextEdit(self.widget1)
        self.textEdit.setGeometry(QtCore.QRect(30, 70, 831, 551))
        self.textEdit.setObjectName("textEdit")
        self.label_16 = QtWidgets.QLabel(self.widget1)
        self.label_16.setGeometry(QtCore.QRect(30, 40, 81, 21))
        self.label_16.setObjectName("label_16")
        self.tabWidget.addTab(self.widget1, icon3, "")
        self.tab_3 = QtWidgets.QWidget()
        self.tab_3.setObjectName("tab_3")
        self.pushButton = QtWidgets.QPushButton(self.tab_3)
        self.pushButton.setGeometry(QtCore.QRect(50, 80, 75, 23))
        self.pushButton.setObjectName("pushButton")
        self.label = QtWidgets.QLabel(self.tab_3)
        self.label.setGeometry(QtCore.QRect(50, 50, 191, 16))
        self.label.setObjectName("label")
        self.textBrowser = QtWidgets.QTextBrowser(self.tab_3)
        self.textBrowser.setGeometry(QtCore.QRect(50, 120, 791, 571))
        self.textBrowser.setObjectName("textBrowser")
        self.pushButton_2 = QtWidgets.QPushButton(self.tab_3)
        self.pushButton_2.setGeometry(QtCore.QRect(130, 80, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.tab_3)
        self.pushButton_3.setGeometry(QtCore.QRect(220, 80, 75, 23))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.tab_3)
        self.pushButton_4.setGeometry(QtCore.QRect(310, 80, 75, 23))
        self.pushButton_4.setObjectName("pushButton_4")
        self.tabWidget.addTab(self.tab_3, icon, "")
        self.tab_4 = QtWidgets.QWidget()
        self.tab_4.setObjectName("tab_4")
        self.label_5 = QtWidgets.QLabel(self.tab_4)
        self.label_5.setGeometry(QtCore.QRect(450, 30, 41, 21))
        self.label_5.setObjectName("label_5")
        self.lineEdit_6 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_6.setGeometry(QtCore.QRect(500, 30, 113, 20))
        self.lineEdit_6.setObjectName("lineEdit_6")
        self.label_24 = QtWidgets.QLabel(self.tab_4)
        self.label_24.setGeometry(QtCore.QRect(40, 30, 91, 21))
        self.label_24.setObjectName("label_24")
        self.pushButton_5 = QtWidgets.QPushButton(self.tab_4)
        self.pushButton_5.setGeometry(QtCore.QRect(770, 630, 75, 23))
        self.pushButton_5.setObjectName("pushButton_5")
        self.textBrowser_5 = QtWidgets.QTextBrowser(self.tab_4)
        self.textBrowser_5.setGeometry(QtCore.QRect(470, 410, 381, 191))
        self.textBrowser_5.setObjectName("textBrowser_5")
        self.comboBox_14 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_14.setGeometry(QtCore.QRect(500, 110, 31, 21))
        self.comboBox_14.setObjectName("comboBox_14")
        self.comboBox_15 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_15.setGeometry(QtCore.QRect(650, 200, 91, 21))
        self.comboBox_15.setObjectName("comboBox_15")
        self.comboBox_15.addItem("")
        self.comboBox_15.addItem("")
        self.comboBox_15.addItem("")
        self.comboBox_15.addItem("")
        self.comboBox_15.addItem("")
        self.comboBox_15.addItem("")
        self.comboBox_16 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_16.setGeometry(QtCore.QRect(650, 170, 91, 21))
        self.comboBox_16.setObjectName("comboBox_16")
        self.comboBox_16.addItem("")
        self.comboBox_16.addItem("")
        self.comboBox_16.addItem("")
        self.comboBox_16.addItem("")
        self.comboBox_16.addItem("")
        self.comboBox_16.addItem("")
        self.comboBox_17 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_17.setGeometry(QtCore.QRect(540, 170, 91, 21))
        self.comboBox_17.setObjectName("comboBox_17")
        self.comboBox_17.addItem("")
        self.comboBox_17.addItem("")
        self.label_15 = QtWidgets.QLabel(self.tab_4)
        self.label_15.setGeometry(QtCore.QRect(490, 230, 41, 21))
        self.label_15.setObjectName("label_15")
        self.comboBox_18 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_18.setGeometry(QtCore.QRect(540, 200, 91, 21))
        self.comboBox_18.setObjectName("comboBox_18")
        self.comboBox_18.addItem("")
        self.label_11 = QtWidgets.QLabel(self.tab_4)
        self.label_11.setGeometry(QtCore.QRect(450, 170, 71, 21))
        self.label_11.setObjectName("label_11")
        self.lineEdit_7 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_7.setGeometry(QtCore.QRect(760, 200, 111, 20))
        self.lineEdit_7.setObjectName("lineEdit_7")
        self.lineEdit_10 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_10.setGeometry(QtCore.QRect(760, 110, 113, 20))
        self.lineEdit_10.setObjectName("lineEdit_10")
        self.lineEdit_11 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_11.setGeometry(QtCore.QRect(760, 70, 113, 20))
        self.lineEdit_11.setObjectName("lineEdit_11")
        self.comboBox_19 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_19.setGeometry(QtCore.QRect(540, 230, 91, 21))
        self.comboBox_19.setObjectName("comboBox_19")
        self.comboBox_19.addItem("")
        self.label_13 = QtWidgets.QLabel(self.tab_4)
        self.label_13.setGeometry(QtCore.QRect(450, 70, 71, 21))
        self.label_13.setObjectName("label_13")
        self.comboBox_20 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_20.setGeometry(QtCore.QRect(540, 110, 91, 21))
        self.comboBox_20.setObjectName("comboBox_20")
        self.comboBox_20.addItem("")
        self.comboBox_21 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_21.setGeometry(QtCore.QRect(540, 70, 91, 21))
        self.comboBox_21.setObjectName("comboBox_21")
        self.comboBox_21.addItem("")
        self.lineEdit_12 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_12.setGeometry(QtCore.QRect(760, 230, 111, 20))
        self.lineEdit_12.setObjectName("lineEdit_12")
        self.label_26 = QtWidgets.QLabel(self.tab_4)
        self.label_26.setGeometry(QtCore.QRect(460, 110, 41, 21))
        self.label_26.setObjectName("label_26")
        self.comboBox_22 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_22.setGeometry(QtCore.QRect(650, 230, 91, 21))
        self.comboBox_22.setObjectName("comboBox_22")
        self.comboBox_22.addItem("")
        self.comboBox_23 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_23.setGeometry(QtCore.QRect(650, 70, 91, 21))
        self.comboBox_23.setObjectName("comboBox_23")
        self.comboBox_23.addItem("")
        self.comboBox_23.addItem("")
        self.comboBox_23.addItem("")
        self.comboBox_23.addItem("")
        self.comboBox_23.addItem("")
        self.comboBox_23.addItem("")
        self.lineEdit_13 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_13.setGeometry(QtCore.QRect(760, 170, 113, 20))
        self.lineEdit_13.setObjectName("lineEdit_13")
        self.comboBox_24 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_24.setGeometry(QtCore.QRect(650, 110, 91, 21))
        self.comboBox_24.setObjectName("comboBox_24")
        self.comboBox_24.addItem("")
        self.label_27 = QtWidgets.QLabel(self.tab_4)
        self.label_27.setGeometry(QtCore.QRect(450, 370, 91, 21))
        self.label_27.setObjectName("label_27")
        self.listWidget_6 = QtWidgets.QListWidget(self.tab_4)
        self.listWidget_6.setGeometry(QtCore.QRect(40, 410, 411, 251))
        self.listWidget_6.setObjectName("listWidget_6")
        item = QtWidgets.QListWidgetItem()
        self.listWidget_6.addItem(item)
        self.label_28 = QtWidgets.QLabel(self.tab_4)
        self.label_28.setGeometry(QtCore.QRect(40, 120, 91, 21))
        self.label_28.setObjectName("label_28")
        self.label_29 = QtWidgets.QLabel(self.tab_4)
        self.label_29.setGeometry(QtCore.QRect(40, 220, 91, 21))
        self.label_29.setObjectName("label_29")
        self.label_30 = QtWidgets.QLabel(self.tab_4)
        self.label_30.setGeometry(QtCore.QRect(40, 380, 91, 21))
        self.label_30.setObjectName("label_30")
        self.tabWidget.addTab(self.tab_4, icon1, "")
        self.gridLayout.addWidget(self.tabWidget, 0, 1, 1, 1)

        self.retranslateUi(SideBarDemo)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(SideBarDemo)

    def retranslateUi(self, SideBarDemo):
        _translate = QtCore.QCoreApplication.translate
        SideBarDemo.setWindowTitle(_translate("SideBarDemo", "认知与决策建模仿真"))
        self.sideBar.setProperty("class", _translate("SideBarDemo", "SideBar"))
        self.widget.setProperty("class", _translate("SideBarDemo", "Separator"))
        self.toolButton_4.setText(_translate("SideBarDemo", "行为仿真"))
        self.toolButton_3.setText(_translate("SideBarDemo", "认知建模"))
        self.toolButton_3.clicked.connect(self.jumpNew3)
        self.toolButton_5.setText(_translate("SideBarDemo", "绩效评价"))
        self.toolButton_1.setText(_translate("SideBarDemo", "知识与参数"))
        self.toolButton_2.setText(_translate("SideBarDemo", "行为分析"))
        self.pushButton_6.setText(_translate("SideBarDemo", "模型检查"))
        self.textEdit.setHtml(_translate("SideBarDemo", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">(p start</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">   =goal&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      ISA         count-from</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      start       =num1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      count       nil</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> ==&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">   =goal&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      count       =num1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">   +retrieval&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      ISA         count-order</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      first       =num1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">)</p></body></html>"))
        self.label_16.setText(_translate("SideBarDemo", "认知模型"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.widget1), _translate("SideBarDemo", "模型预览"))
        self.pushButton.setText(_translate("SideBarDemo", "Run"))
        self.label.setText(_translate("SideBarDemo", "Model Name:Three position"))
        self.pushButton_2.setText(_translate("SideBarDemo", "Pause"))
        self.pushButton_3.setText(_translate("SideBarDemo", "Clear"))
        self.pushButton_4.setText(_translate("SideBarDemo", "Restart"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), _translate("SideBarDemo", "模型运行"))
        self.label_5.setText(_translate("SideBarDemo", "时间"))
        self.lineEdit_6.setText(_translate("SideBarDemo", "1\'12:1234"))
        self.label_24.setText(_translate("SideBarDemo", "系统参数"))
        self.pushButton_5.setText(_translate("SideBarDemo", "保存"))
        self.textBrowser_5.setHtml(_translate("SideBarDemo", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">(p start</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">   =goal&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      ISA         count-from</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      start       =num1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      count       nil</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> ==&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">   =goal&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      count       =num1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">   +retrieval&gt;</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      ISA         count-order</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">      first       =num1</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">)</p></body></html>"))
        self.comboBox_15.setItemText(0, _translate("SideBarDemo", "IS"))
        self.comboBox_15.setItemText(1, _translate("SideBarDemo", "="))
        self.comboBox_15.setItemText(2, _translate("SideBarDemo", ">"))
        self.comboBox_15.setItemText(3, _translate("SideBarDemo", "<"))
        self.comboBox_15.setItemText(4, _translate("SideBarDemo", ">="))
        self.comboBox_15.setItemText(5, _translate("SideBarDemo", "<="))
        self.comboBox_16.setItemText(0, _translate("SideBarDemo", "count"))
        self.comboBox_16.setItemText(1, _translate("SideBarDemo", "="))
        self.comboBox_16.setItemText(2, _translate("SideBarDemo", ">"))
        self.comboBox_16.setItemText(3, _translate("SideBarDemo", "<"))
        self.comboBox_16.setItemText(4, _translate("SideBarDemo", ">="))
        self.comboBox_16.setItemText(5, _translate("SideBarDemo", "<="))
        self.comboBox_17.setItemText(0, _translate("SideBarDemo", "goal"))
        self.comboBox_17.setItemText(1, _translate("SideBarDemo", "count-order"))
        self.label_15.setText(_translate("SideBarDemo", "<html><head/><body><p><span style=\" font-size:14pt;\">+   -</span></p></body></html>"))
        self.comboBox_18.setItemText(0, _translate("SideBarDemo", "retrieve"))
        self.label_11.setText(_translate("SideBarDemo", "结果"))
        self.lineEdit_7.setText(_translate("SideBarDemo", "counter-order"))
        self.lineEdit_10.setText(_translate("SideBarDemo", "num1"))
        self.lineEdit_11.setText(_translate("SideBarDemo", "count-from"))
        self.comboBox_19.setItemText(0, _translate("SideBarDemo", "first"))
        self.label_13.setText(_translate("SideBarDemo", "条件"))
        self.comboBox_20.setItemText(0, _translate("SideBarDemo", "start"))
        self.comboBox_21.setItemText(0, _translate("SideBarDemo", "goal"))
        self.lineEdit_12.setText(_translate("SideBarDemo", "num1"))
        self.label_26.setText(_translate("SideBarDemo", "<html><head/><body><p><span style=\" font-size:14pt;\">+   -</span></p></body></html>"))
        self.comboBox_22.setItemText(0, _translate("SideBarDemo", "="))
        self.comboBox_23.setItemText(0, _translate("SideBarDemo", "IS"))
        self.comboBox_23.setItemText(1, _translate("SideBarDemo", "="))
        self.comboBox_23.setItemText(2, _translate("SideBarDemo", ">"))
        self.comboBox_23.setItemText(3, _translate("SideBarDemo", "<"))
        self.comboBox_23.setItemText(4, _translate("SideBarDemo", ">="))
        self.comboBox_23.setItemText(5, _translate("SideBarDemo", "<="))
        self.lineEdit_13.setText(_translate("SideBarDemo", "num1"))
        self.comboBox_24.setItemText(0, _translate("SideBarDemo", "="))
        self.label_27.setText(_translate("SideBarDemo", "过程知识"))
        __sortingEnabled = self.listWidget_6.isSortingEnabled()
        self.listWidget_6.setSortingEnabled(False)
        item = self.listWidget_6.item(0)
        item.setText(_translate("SideBarDemo", "start"))
        self.listWidget_6.setSortingEnabled(__sortingEnabled)
        self.label_28.setText(_translate("SideBarDemo", "模型参数"))
        self.label_29.setText(_translate("SideBarDemo", "陈述知识"))
        self.label_30.setText(_translate("SideBarDemo", "过程知识"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), _translate("SideBarDemo", "参数调整"))
