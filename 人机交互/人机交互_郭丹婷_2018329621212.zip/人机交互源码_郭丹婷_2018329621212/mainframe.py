# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainframe.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
import cogmod
import procedure
import resources

class Ui_SideBarDemo(object):

    def jumpNew2(self):
        self.sideWindow = QtWidgets.QWidget()
        self.sideBarUi = procedure.Ui_SideBarDemo()
        self.sideBarUi.setupUi(self.sideWindow)
        self.sideWindow.show()

    def jumpNew3(self):
        self.sideWindow = QtWidgets.QWidget()
        self.sideBarUi = cogmod.Ui_SideBarDemo()
        self.sideBarUi.setupUi(self.sideWindow)
        self.sideWindow.show()

    def addfir(self):
        self.combobox1.append(self.comboBox.currentText())
        self.lineedit1.append(self.lineEdit.text())

        #增加列表
        self.listWidget.addItem(self.comboBox.currentText()+"                                "+self.lineEdit.text()+\
                                "                                      "+self.lineEdit_8.text())
        self.lineEdit.clear()
        self.lineEdit_8.clear()
        self.textbroswer1show()

    #第一个展示
    def textbroswer1show(self):
        count = self.listWidget.count() - 1
        print(count)
        if(count == 0):
            self.word1 = ""
            self.textBrowser.clear()
            return
        word = "(sgp "
        for i in range(count):
            word = word + " :" + self.combobox1[i] + " " + self.lineedit1[i]
        word = word + ")"
        self.word1 = word
        self.textBrowser.setText(self.word1)


    def addsec(self):
        # 增加列表
        self.listWidget_2.addItem(self.lineEdit_2.text() +"                                    " +  self.comboBox_2.currentText())
        self.lineEdit_2.clear()

        count = self.listWidget_2.count() - 1
        self.textBrowser_2.clear()
        self.lineEdit_7.clear()
        for i in range(count):
            self.textBrowser_2.append(self.listWidget_2.item(i+1).text())



    def addthird(self):
        self.combobox3.append(self.lineEdit_3.text())
        self.listWidget_3.addItem(self.lineEdit_3.text() + "                          " + self.comboBox_3.currentText())

        self.comboBox_4.clear()
        self.comboBox_4.addItems(self.combobox3)
        self.lineedit3.append(self.lineEdit_3.text() + " " + self.comboBox_3.currentText())
        self.lineEdit_3.clear()
        self.textbrowser3show()


    def addfourth(self):

        groove = self.comboBox_5.currentText() + " " + self.lineEdit_4.text()+ " " + \
                 self.comboBox_6.currentText() + " " + self.lineEdit_5.text()

        if(self.lineEdit_6.text().__len__() > 2):
            self.listWidget_4.addItem(self.lineEdit_6.text() + "   " + self.comboBox_4.currentText() + "          " + groove)
        else:
            self.listWidget_4.addItem(self.lineEdit_6.text() + "               " + self.comboBox_4.currentText() + "          " + groove)

        self.knowledge.append(self.comboBox_4.currentText() + "  " + groove)
        self.knowledgename.append(self.lineEdit_6.text())
        self.lineEdit_6.clear()
        self.textbrowser3show()
        self.fileoperation()


    #文本框显示
    def textbrowser3show(self):
        self.textBrowser_3.clear()
        count1 = self.listWidget_3.count() - 1
        word = ""
        for i in range(count1):
            word = word + "(chunk-type " + self.lineedit3[i] + ")\n"

        count2 = self.listWidget_4.count() - 1
        if(count2 != 0):
            word = word + "\n(add-dm\n"
        for j in range(count2):
            word = word + "(" + self.knowledgename[j] + " ISA " + self.knowledge[j] + ")\n"
        word = word + ")"
        self.textBrowser_3.setText(word)
        self.word2 = word
        print(word)

    def fileoperation(self):
        file = open("result.list","w")
        file.write("(clear-all)\n\n (define-model count\n\n")
        file.write(self.word1 + "\n\n\n")
        file.write(self.word2 + "\n\n")
        file.close()

    #删除listweidge
    def funcdel(self):
        item = self.listWidget.currentItem()
        self.listWidget.takeItem(self.listWidget.row(item))
        self.textbroswer1show()

    def funcdel2(self):
        item = self.listWidget_2.currentItem()
        self.listWidget_2.takeItem(self.listWidget_2.row(item))
        count = self.listWidget_2.count() - 1
        self.textBrowser_2.clear()
        self.lineEdit_7.clear()
        for i in range(count):
            self.textBrowser_2.append(self.listWidget_2.item(i + 1).text())




    def setupUi(self, SideBarDemo):
        self.combobox1 = []
        self.lineedit1 = []
        self.combobox3 = []
        self.lineedit3 = []
        self.word1 = ""
        self.word2 = ""

        #知识类
        self.knowledge = []

        #知识名
        self.knowledgename = []


        SideBarDemo.setObjectName("SideBarDemo")
        SideBarDemo.resize(1024, 768)
        SideBarDemo.setStyleSheet("QWidget.SideBar {\n"
"    border-right: 1px solid rgb(170, 170, 170);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(50, 50, 50, 255),\n"
"        stop:1 rgba(150, 150, 150, 255));\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton {\n"
"    font-size: 13px;\n"
"    font-weight: normal;\n"
"    border: none;\n"
"    color: rgb(240,240,240);\n"
"\n"
"    padding-left:12px;\n"
"    padding-right: 12px;\n"
"    padding-top: 5px;\n"
"\n"
"    border-top: 1px dashed rgba(0,0,0,0);\n"
"    border-bottom: 1px dashed rgba(0,0,0,0);\n"
"    border-right: 1px dashed rgba(0,0,0,0);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton:hover {\n"
"    color: rgb(200, 200, 200);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[current=\"true\"] {\n"
"    border-top: 1px solid rgb(90,90,90);\n"
"    border-right: 1px solid rgb(200, 200, 200, 200);\n"
"    border-bottom: 1px solid rgb(90,90,90);\n"
"    color: black;\n"
"    background: qlineargradient(spread:pad,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(130, 130, 130, 255),\n"
"        stop:1 rgba(230, 230, 230, 255));\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}\n"
"\n"
"QWidget.SideBar .Separator {\n"
"    border: none;\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(10, 10, 10, 255),\n"
"        stop:1 rgba(220, 220, 220, 255));\n"
"}\n"
"\n"
"#content {\n"
"    border: none;\n"
"    border-left: 1px solid gray;\n"
"    background: rgba(0, 255, 0, 100);\n"
"}")
        SideBarDemo.setProperty("class", "")
        self.gridLayout = QtWidgets.QGridLayout(SideBarDemo)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setHorizontalSpacing(0)
        self.gridLayout.setVerticalSpacing(6)
        self.gridLayout.setObjectName("gridLayout")
        self.sideBar = QtWidgets.QWidget(SideBarDemo)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.sideBar.sizePolicy().hasHeightForWidth())
        self.sideBar.setSizePolicy(sizePolicy)
        self.sideBar.setMinimumSize(QtCore.QSize(90, 0))
        self.sideBar.setObjectName("sideBar")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.sideBar)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setSpacing(6)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.toolButton_2 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_2.sizePolicy().hasHeightForWidth())
        self.toolButton_2.setSizePolicy(sizePolicy)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/images/resources/button-4.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_2.setIcon(icon)
        self.toolButton_2.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_2.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_2.setObjectName("toolButton_2")
        self.gridLayout_2.addWidget(self.toolButton_2, 2, 0, 1, 1)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout_2.addItem(spacerItem, 7, 0, 1, 1)
        self.widget = QtWidgets.QWidget(self.sideBar)
        self.widget.setMinimumSize(QtCore.QSize(0, 1))
        self.widget.setMaximumSize(QtCore.QSize(16777215, 1))
        self.widget.setObjectName("widget")
        self.gridLayout_2.addWidget(self.widget, 4, 0, 1, 1)
        self.toolButton_5 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_5.sizePolicy().hasHeightForWidth())
        self.toolButton_5.setSizePolicy(sizePolicy)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/images/resources/button-1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_5.setIcon(icon1)
        self.toolButton_5.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_5.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_5.setObjectName("toolButton_5")
        self.gridLayout_2.addWidget(self.toolButton_5, 6, 0, 1, 1)
        self.toolButton_1 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_1.sizePolicy().hasHeightForWidth())
        self.toolButton_1.setSizePolicy(sizePolicy)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/images/resources/button-2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_1.setIcon(icon2)
        self.toolButton_1.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_1.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_1.setObjectName("toolButton_1")
        self.gridLayout_2.addWidget(self.toolButton_1, 1, 0, 1, 1)
        self.toolButton_3 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_3.sizePolicy().hasHeightForWidth())
        self.toolButton_3.setSizePolicy(sizePolicy)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(":/images/resources/button-5.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_3.setIcon(icon3)
        self.toolButton_3.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_3.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_3.setObjectName("toolButton_3")
        self.gridLayout_2.addWidget(self.toolButton_3, 3, 0, 1, 1)
        self.toolButton_4 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_4.sizePolicy().hasHeightForWidth())
        self.toolButton_4.setSizePolicy(sizePolicy)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(":/images/resources/button-3.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_4.setIcon(icon4)
        self.toolButton_4.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_4.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_4.setObjectName("toolButton_4")
        self.gridLayout_2.addWidget(self.toolButton_4, 5, 0, 1, 1)
        self.gridLayout.addWidget(self.sideBar, 0, 0, 1, 1)
        self.tabWidget = QtWidgets.QTabWidget(SideBarDemo)
        self.tabWidget.setObjectName("tabWidget")
        self.widget1 = QtWidgets.QWidget()
        self.widget1.setObjectName("widget1")
        self.listWidget = QtWidgets.QListWidget(self.widget1)
        self.listWidget.setGeometry(QtCore.QRect(490, 80, 411, 192))
        self.listWidget.setObjectName("listWidget")
        item = QtWidgets.QListWidgetItem()
        self.listWidget.addItem(item)

        #按钮功能的添加
        self.listWidget.itemClicked.connect(self.funcdel)

        self.comboBox = QtWidgets.QComboBox(self.widget1)
        self.comboBox.setGeometry(QtCore.QRect(100, 80, 91, 31))
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.label = QtWidgets.QLabel(self.widget1)
        self.label.setGeometry(QtCore.QRect(40, 80, 41, 21))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.widget1)
        self.label_2.setGeometry(QtCore.QRect(250, 80, 41, 21))
        self.label_2.setObjectName("label_2")
        self.lineEdit = QtWidgets.QLineEdit(self.widget1)
        self.lineEdit.setGeometry(QtCore.QRect(310, 80, 113, 20))
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton = QtWidgets.QPushButton(self.widget1)
        self.pushButton.setGeometry(QtCore.QRect(350, 150, 75, 23))
        self.pushButton.setObjectName("pushButton")
        self.textBrowser = QtWidgets.QTextBrowser(self.widget1)
        self.textBrowser.setGeometry(QtCore.QRect(100, 370, 791, 301))
        self.textBrowser.setObjectName("textBrowser")
        self.label_3 = QtWidgets.QLabel(self.widget1)
        self.label_3.setGeometry(QtCore.QRect(30, 370, 51, 21))
        self.label_3.setObjectName("label_3")
        self.label_20 = QtWidgets.QLabel(self.widget1)
        self.label_20.setGeometry(QtCore.QRect(40, 150, 72, 15))
        self.label_20.setObjectName("label_20")
        self.lineEdit_8 = QtWidgets.QLineEdit(self.widget1)
        self.lineEdit_8.setGeometry(QtCore.QRect(100, 150, 113, 21))
        self.lineEdit_8.setObjectName("lineEdit_8")
        self.tabWidget.addTab(self.widget1, icon2, "")
        self.tab_4 = QtWidgets.QWidget()
        self.tab_4.setObjectName("tab_4")
        self.pushButton_2 = QtWidgets.QPushButton(self.tab_4)
        self.pushButton_2.setGeometry(QtCore.QRect(350, 140, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.comboBox_2 = QtWidgets.QComboBox(self.tab_4)
        self.comboBox_2.setGeometry(QtCore.QRect(250, 70, 91, 21))
        self.comboBox_2.setObjectName("comboBox_2")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.textBrowser_2 = QtWidgets.QTextBrowser(self.tab_4)
        self.textBrowser_2.setGeometry(QtCore.QRect(100, 360, 791, 301))
        self.textBrowser_2.setObjectName("textBrowser_2")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_2.setGeometry(QtCore.QRect(60, 70, 113, 20))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.label_4 = QtWidgets.QLabel(self.tab_4)
        self.label_4.setGeometry(QtCore.QRect(10, 360, 81, 21))
        self.label_4.setObjectName("label_4")
        self.listWidget_2 = QtWidgets.QListWidget(self.tab_4)
        self.listWidget_2.setGeometry(QtCore.QRect(490, 70, 411, 192))
        self.listWidget_2.setObjectName("listWidget_2")
        item = QtWidgets.QListWidgetItem()
        self.listWidget_2.addItem(item)

        self.listWidget_2.itemClicked.connect(self.funcdel2)

        self.label_5 = QtWidgets.QLabel(self.tab_4)
        self.label_5.setGeometry(QtCore.QRect(10, 70, 41, 21))
        self.label_5.setObjectName("label_5")
        self.label_8 = QtWidgets.QLabel(self.tab_4)
        self.label_8.setGeometry(QtCore.QRect(190, 70, 61, 21))
        self.label_8.setObjectName("label_8")
        self.label_19 = QtWidgets.QLabel(self.tab_4)
        self.label_19.setGeometry(QtCore.QRect(190, 110, 61, 21))
        self.label_19.setObjectName("label_19")
        self.lineEdit_7 = QtWidgets.QLineEdit(self.tab_4)
        self.lineEdit_7.setGeometry(QtCore.QRect(250, 110, 113, 20))
        self.lineEdit_7.setObjectName("lineEdit_7")
        self.tabWidget.addTab(self.tab_4, icon3, "")
        self.tab_3 = QtWidgets.QWidget()
        self.tab_3.setObjectName("tab_3")
        self.pushButton_3 = QtWidgets.QPushButton(self.tab_3)
        self.pushButton_3.setGeometry(QtCore.QRect(320, 130, 75, 23))
        self.pushButton_3.setObjectName("pushButton_3")
        self.comboBox_3 = QtWidgets.QComboBox(self.tab_3)
        self.comboBox_3.setGeometry(QtCore.QRect(300, 60, 91, 31))
        self.comboBox_3.setObjectName("comboBox_3")
        self.comboBox_3.addItem("")
        self.comboBox_3.addItem("")
        self.textBrowser_3 = QtWidgets.QTextBrowser(self.tab_3)
        self.textBrowser_3.setGeometry(QtCore.QRect(110, 520, 791, 191))
        self.textBrowser_3.setObjectName("textBrowser_3")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.tab_3)
        self.lineEdit_3.setGeometry(QtCore.QRect(100, 60, 113, 20))
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.label_6 = QtWidgets.QLabel(self.tab_3)
        self.label_6.setGeometry(QtCore.QRect(10, 520, 81, 21))
        self.label_6.setObjectName("label_6")
        self.listWidget_3 = QtWidgets.QListWidget(self.tab_3)
        self.listWidget_3.setGeometry(QtCore.QRect(470, 60, 411, 192))
        self.listWidget_3.setObjectName("listWidget_3")
        item = QtWidgets.QListWidgetItem()
        self.listWidget_3.addItem(item)

        self.label_7 = QtWidgets.QLabel(self.tab_3)
        self.label_7.setGeometry(QtCore.QRect(20, 20, 91, 21))
        self.label_7.setObjectName("label_7")
        self.label_9 = QtWidgets.QLabel(self.tab_3)
        self.label_9.setGeometry(QtCore.QRect(240, 60, 41, 21))
        self.label_9.setObjectName("label_9")
        self.label_10 = QtWidgets.QLabel(self.tab_3)
        self.label_10.setGeometry(QtCore.QRect(20, 210, 71, 21))
        self.label_10.setObjectName("label_10")
        self.listWidget_4 = QtWidgets.QListWidget(self.tab_3)
        self.listWidget_4.setGeometry(QtCore.QRect(470, 280, 411, 192))
        self.listWidget_4.setObjectName("listWidget_4")
        item = QtWidgets.QListWidgetItem()
        self.listWidget_4.addItem(item)

        self.label_11 = QtWidgets.QLabel(self.tab_3)
        self.label_11.setGeometry(QtCore.QRect(110, 280, 21, 21))
        self.label_11.setObjectName("label_11")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.tab_3)
        self.lineEdit_4.setGeometry(QtCore.QRect(290, 280, 111, 20))
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.comboBox_4 = QtWidgets.QComboBox(self.tab_3)
        self.comboBox_4.setGeometry(QtCore.QRect(210, 240, 91, 21))
        self.comboBox_4.setObjectName("comboBox_4")
        self.comboBox_4.addItem("")
        self.pushButton_4 = QtWidgets.QPushButton(self.tab_3)
        self.pushButton_4.setGeometry(QtCore.QRect(110, 430, 75, 23))
        self.pushButton_4.setObjectName("pushButton_4")
        self.label_12 = QtWidgets.QLabel(self.tab_3)
        self.label_12.setGeometry(QtCore.QRect(30, 60, 71, 21))
        self.label_12.setObjectName("label_12")
        self.comboBox_5 = QtWidgets.QComboBox(self.tab_3)
        self.comboBox_5.setGeometry(QtCore.QRect(130, 280, 91, 21))
        self.comboBox_5.setObjectName("comboBox_5")
        self.comboBox_5.addItem("")
        self.comboBox_5.addItem("")
        self.label_13 = QtWidgets.QLabel(self.tab_3)
        self.label_13.setGeometry(QtCore.QRect(260, 280, 21, 21))
        self.label_13.setObjectName("label_13")
        self.label_14 = QtWidgets.QLabel(self.tab_3)
        self.label_14.setGeometry(QtCore.QRect(50, 330, 41, 21))
        self.label_14.setObjectName("label_14")
        self.label_15 = QtWidgets.QLabel(self.tab_3)
        self.label_15.setGeometry(QtCore.QRect(110, 330, 21, 21))
        self.label_15.setObjectName("label_15")
        self.label_16 = QtWidgets.QLabel(self.tab_3)
        self.label_16.setGeometry(QtCore.QRect(260, 330, 21, 21))
        self.label_16.setObjectName("label_16")
        self.lineEdit_5 = QtWidgets.QLineEdit(self.tab_3)
        self.lineEdit_5.setGeometry(QtCore.QRect(290, 330, 111, 20))
        self.lineEdit_5.setObjectName("lineEdit_5")
        self.comboBox_6 = QtWidgets.QComboBox(self.tab_3)
        self.comboBox_6.setGeometry(QtCore.QRect(130, 330, 91, 21))
        self.comboBox_6.setObjectName("comboBox_6")
        self.comboBox_6.addItem("")
        self.comboBox_6.addItem("")
        self.lineEdit_6 = QtWidgets.QLineEdit(self.tab_3)
        self.lineEdit_6.setGeometry(QtCore.QRect(90, 240, 61, 20))
        self.lineEdit_6.setObjectName("lineEdit_6")
        self.label_17 = QtWidgets.QLabel(self.tab_3)
        self.label_17.setGeometry(QtCore.QRect(50, 240, 41, 21))
        self.label_17.setObjectName("label_17")
        self.label_18 = QtWidgets.QLabel(self.tab_3)
        self.label_18.setGeometry(QtCore.QRect(170, 240, 41, 21))
        self.label_18.setObjectName("label_18")
        self.checkBox = QtWidgets.QCheckBox(self.tab_3)
        self.checkBox.setGeometry(QtCore.QRect(110, 380, 71, 16))
        self.checkBox.setObjectName("checkBox")
        self.tabWidget.addTab(self.tab_3, icon4, "")
        self.gridLayout.addWidget(self.tabWidget, 0, 1, 1, 1)

        self.retranslateUi(SideBarDemo)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(SideBarDemo)

    def retranslateUi(self, SideBarDemo):
        _translate = QtCore.QCoreApplication.translate
        SideBarDemo.setWindowTitle(_translate("SideBarDemo", "认知与决策建模仿真"))
        self.sideBar.setProperty("class", _translate("SideBarDemo", "SideBar"))
        self.toolButton_2.setText(_translate("SideBarDemo", "行为分析"))

        self.toolButton_2.clicked.connect(self.jumpNew2)


        self.widget.setProperty("class", _translate("SideBarDemo", "Separator"))
        self.toolButton_5.setText(_translate("SideBarDemo", "绩效评价"))
        self.toolButton_1.setText(_translate("SideBarDemo", "知识与参数"))
        self.toolButton_3.setText(_translate("SideBarDemo", "认知建模"))

        self.toolButton_3.clicked.connect(self.jumpNew3)


        self.toolButton_4.setText(_translate("SideBarDemo", "行为仿真"))
        __sortingEnabled = self.listWidget.isSortingEnabled()
        self.listWidget.setSortingEnabled(False)
        item = self.listWidget.item(0)
        item.setText(_translate("SideBarDemo", "参数                                   取     值                                  缺省值"))

        self.listWidget.setSortingEnabled(__sortingEnabled)
        self.comboBox.setItemText(0, _translate("SideBarDemo", "trace-detail"))
        self.comboBox.setItemText(1, _translate("SideBarDemo", "If"))
        self.comboBox.setItemText(2, _translate("SideBarDemo", "esc"))
        self.label.setText(_translate("SideBarDemo", "参数名"))
        self.label_2.setText(_translate("SideBarDemo", "参数值"))
        self.pushButton.setText(_translate("SideBarDemo", "增加"))

        # 添加按钮1
        self.pushButton.clicked.connect(self.addfir)


        self.textBrowser.setHtml(_translate("SideBarDemo", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">(sgp :esc t :lf .05 :trace-detail high)</p></body></html>"))
        self.textBrowser.clear()

        self.label_3.setText(_translate("SideBarDemo", "模型预览"))
        self.label_20.setText(_translate("SideBarDemo", "缺省值"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.widget1), _translate("SideBarDemo", "系统参数"))
        self.pushButton_2.setText(_translate("SideBarDemo", "增加"))

        # 添加按钮2
        self.pushButton_2.clicked.connect(self.addsec)



        self.comboBox_2.setItemText(0, _translate("SideBarDemo", "整形"))
        self.comboBox_2.setItemText(1, _translate("SideBarDemo", "浮点型"))
        self.textBrowser_2.setHtml(_translate("SideBarDemo", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">first   整数</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">second  整数</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">start   整数</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">end     整数</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">count   整数</p></body></html>"))
        self.textBrowser_2.clear()

        self.label_4.setText(_translate("SideBarDemo", "模型参数预览"))
        __sortingEnabled = self.listWidget_2.isSortingEnabled()
        self.listWidget_2.setSortingEnabled(False)
        item = self.listWidget_2.item(0)
        item.setText(_translate("SideBarDemo", "参数                                   类型                                  缺省值"))

        self.listWidget_2.setSortingEnabled(__sortingEnabled)
        self.label_5.setText(_translate("SideBarDemo", "参数名"))
        self.label_8.setText(_translate("SideBarDemo", "参数类型"))
        self.label_19.setText(_translate("SideBarDemo", "缺省值"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), _translate("SideBarDemo", "模型参数"))
        self.pushButton_3.setText(_translate("SideBarDemo", "增加"))

        # 添加按钮3
        self.pushButton_3.clicked.connect(self.addthird)

        self.comboBox_3.setItemText(0, _translate("SideBarDemo", "first second"))
        self.comboBox_3.setItemText(1, _translate("SideBarDemo", "start end count"))
        self.textBrowser_3.setHtml(_translate("SideBarDemo", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">(chunk-type count-order first second)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">(chunk-type count-from start end count)</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">(add-dm</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> (b ISA count-order first 1 second 2)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> (c ISA count-order first 2 second 3)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> (d ISA count-order first 3 second 4)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> (e ISA count-order first 4 second 5)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> (f ISA count-order first 5 second 6)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> (first-goal ISA count-from start 2 end 4)</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"> )</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))

        self.textBrowser_3.clear()
        self.label_6.setText(_translate("SideBarDemo", "陈述知识预览"))
        __sortingEnabled = self.listWidget_3.isSortingEnabled()
        self.listWidget_3.setSortingEnabled(False)
        item = self.listWidget_3.item(0)
        item.setText(_translate("SideBarDemo", "知识名                                  知识槽                                  ..."))

        self.listWidget_3.setSortingEnabled(__sortingEnabled)
        self.label_7.setText(_translate("SideBarDemo", "陈述知识类定义"))
        self.label_9.setText(_translate("SideBarDemo", "知识槽"))
        self.label_10.setText(_translate("SideBarDemo", "陈述知识定义"))
        __sortingEnabled = self.listWidget_4.isSortingEnabled()
        self.listWidget_4.setSortingEnabled(False)
        item = self.listWidget_4.item(0)
        item.setText(_translate("SideBarDemo", "知识名         知识类                     知识槽                                  ..."))

        self.listWidget_4.setSortingEnabled(__sortingEnabled)
        self.label_11.setText(_translate("SideBarDemo", "槽"))


        self.pushButton_4.setText(_translate("SideBarDemo", "增加"))

        # 添加按钮4
        self.pushButton_4.clicked.connect(self.addfourth)

        self.label_12.setText(_translate("SideBarDemo", "知识类名称"))
        self.comboBox_5.setItemText(0, _translate("SideBarDemo", "first"))
        self.comboBox_5.setItemText(1, _translate("SideBarDemo", "start"))
        self.label_13.setText(_translate("SideBarDemo", "值"))
        self.label_14.setText(_translate("SideBarDemo", "<html><head/><body><p><span style=\" font-size:14pt;\">+   -</span></p></body></html>"))
        self.label_15.setText(_translate("SideBarDemo", "槽"))
        self.label_16.setText(_translate("SideBarDemo", "值"))

        self.comboBox_6.setItemText(0, _translate("SideBarDemo", "second"))
        self.comboBox_6.setItemText(1, _translate("SideBarDemo", "end"))

        self.label_17.setText(_translate("SideBarDemo", "知识名"))
        self.label_18.setText(_translate("SideBarDemo", "知识类"))
        self.checkBox.setText(_translate("SideBarDemo", "初始知识"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), _translate("SideBarDemo", "陈述知识"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QWidget()
    ui = Ui_SideBarDemo()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
