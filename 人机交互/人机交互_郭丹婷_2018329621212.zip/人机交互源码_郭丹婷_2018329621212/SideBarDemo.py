# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SideBarDemo.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
import  resources

class Ui_SideBarDemo(object):
    def setupUi(self, SideBarDemo):
        SideBarDemo.setObjectName("SideBarDemo")
        SideBarDemo.resize(879, 568)
        SideBarDemo.setStyleSheet("QWidget.SideBar {\n"
"    border-right: 1px solid rgb(170, 170, 170);\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(50, 50, 50, 255),\n"
"        stop:1 rgba(150, 150, 150, 255));\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton {\n"
"    font-size: 13px;\n"
"    font-weight: normal;\n"
"    border: none;\n"
"    color: rgb(240,240,240);\n"
"\n"
"    padding-left:12px;\n"
"    padding-right: 12px;\n"
"    padding-top: 5px;\n"
"\n"
"    border-top: 1px dashed rgba(0,0,0,0);\n"
"    border-bottom: 1px dashed rgba(0,0,0,0);\n"
"    border-right: 1px dashed rgba(0,0,0,0);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton:hover {\n"
"    color: rgb(200, 200, 200);\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[current=\"true\"] {\n"
"    border-top: 1px solid rgb(90,90,90);\n"
"    border-right: 1px solid rgb(200, 200, 200, 200);\n"
"    border-bottom: 1px solid rgb(90,90,90);\n"
"    color: black;\n"
"    background: qlineargradient(spread:pad,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(130, 130, 130, 255),\n"
"        stop:1 rgba(230, 230, 230, 255));\n"
"}\n"
"\n"
"QWidget.SideBar QToolButton[first=\"true\"] {\n"
"    border-top: 1px dashed rgba(0, 0, 0, 0);\n"
"}\n"
"\n"
"QWidget.SideBar .Separator {\n"
"    border: none;\n"
"    background: qlineargradient(spread:reflect,\n"
"        x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(10, 10, 10, 255),\n"
"        stop:1 rgba(220, 220, 220, 255));\n"
"}\n"
"\n"
"#content {\n"
"    border: none;\n"
"    border-left: 1px solid gray;\n"
"    background: rgba(0, 255, 0, 100);\n"
"}")
        SideBarDemo.setProperty("class", "")
        self.gridLayout = QtWidgets.QGridLayout(SideBarDemo)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setHorizontalSpacing(0)
        self.gridLayout.setVerticalSpacing(6)
        self.gridLayout.setObjectName("gridLayout")
        self.content = QtWidgets.QLabel(SideBarDemo)
        self.content.setAutoFillBackground(False)
        self.content.setAlignment(QtCore.Qt.AlignCenter)
        self.content.setObjectName("content")
        self.gridLayout.addWidget(self.content, 0, 1, 1, 1)
        self.sideBar = QtWidgets.QWidget(SideBarDemo)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.sideBar.sizePolicy().hasHeightForWidth())
        self.sideBar.setSizePolicy(sizePolicy)
        self.sideBar.setMinimumSize(QtCore.QSize(90, 0))
        self.sideBar.setObjectName("sideBar")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.sideBar)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(6)
        self.verticalLayout.setObjectName("verticalLayout")
        self.toolButton_1 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_1.sizePolicy().hasHeightForWidth())
        self.toolButton_1.setSizePolicy(sizePolicy)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/images/resources/button-2.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_1.setIcon(icon)
        self.toolButton_1.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_1.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_1.setObjectName("toolButton_1")
        self.verticalLayout.addWidget(self.toolButton_1)
        self.toolButton_2 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_2.sizePolicy().hasHeightForWidth())
        self.toolButton_2.setSizePolicy(sizePolicy)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/images/resources/button-4.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_2.setIcon(icon1)
        self.toolButton_2.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_2.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_2.setObjectName("toolButton_2")
        self.verticalLayout.addWidget(self.toolButton_2)
        self.toolButton_3 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_3.sizePolicy().hasHeightForWidth())
        self.toolButton_3.setSizePolicy(sizePolicy)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/images/resources/button-5.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_3.setIcon(icon2)
        self.toolButton_3.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_3.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_3.setObjectName("toolButton_3")
        self.verticalLayout.addWidget(self.toolButton_3)
        self.toolButton_4 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_4.sizePolicy().hasHeightForWidth())
        self.toolButton_4.setSizePolicy(sizePolicy)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(":/images/resources/button-3.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_4.setIcon(icon3)
        self.toolButton_4.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_4.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_4.setObjectName("toolButton_4")
        self.verticalLayout.addWidget(self.toolButton_4)
        self.toolButton_5 = QtWidgets.QToolButton(self.sideBar)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.toolButton_5.sizePolicy().hasHeightForWidth())
        self.toolButton_5.setSizePolicy(sizePolicy)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(":/images/resources/button-1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.toolButton_5.setIcon(icon4)
        self.toolButton_5.setIconSize(QtCore.QSize(64, 64))
        self.toolButton_5.setToolButtonStyle(QtCore.Qt.ToolButtonTextUnderIcon)
        self.toolButton_5.setObjectName("toolButton_5")
        self.verticalLayout.addWidget(self.toolButton_5)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.widget = QtWidgets.QWidget(self.sideBar)
        self.widget.setMinimumSize(QtCore.QSize(0, 1))
        self.widget.setMaximumSize(QtCore.QSize(16777215, 1))
        self.widget.setObjectName("widget")
        self.verticalLayout.addWidget(self.widget)
        self.gridLayout.addWidget(self.sideBar, 0, 0, 1, 1)

        self.retranslateUi(SideBarDemo)
        QtCore.QMetaObject.connectSlotsByName(SideBarDemo)

    def retranslateUi(self, SideBarDemo):
        _translate = QtCore.QCoreApplication.translate
        SideBarDemo.setWindowTitle(_translate("SideBarDemo", "认知与决策建模仿真"))
        self.content.setText(_translate("SideBarDemo", "工作区域"))
        self.sideBar.setProperty("class", _translate("SideBarDemo", "SideBar"))
        self.toolButton_1.setText(_translate("SideBarDemo", "知识与参数"))
        self.toolButton_2.setText(_translate("SideBarDemo", "行为分析"))
        self.toolButton_3.setText(_translate("SideBarDemo", "认知建模"))
        self.toolButton_4.setText(_translate("SideBarDemo", "行为仿真"))
        self.toolButton_5.setText(_translate("SideBarDemo", "绩效评价"))
        self.widget.setProperty("class", _translate("SideBarDemo", "Separator"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow11 = QtWidgets.QWidget()
    ui = Ui_SideBarDemo()
    ui.setupUi(MainWindow11)
    MainWindow11.show()
    sys.exit(app.exec_())