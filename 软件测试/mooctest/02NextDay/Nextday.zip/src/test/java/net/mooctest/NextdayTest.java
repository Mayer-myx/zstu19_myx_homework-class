/**
 * 
 */
package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class NextdayTest {

	@Test
	public void test() {
		Nextday n = new Nextday();
	}

}
