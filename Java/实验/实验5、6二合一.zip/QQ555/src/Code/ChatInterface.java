package Code;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Code.UdpFileReceiver;
import Code.UdpFileSender;
import Code.UdpReceiver;
import Code.UdpSender;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import java.awt.Font;

public class ChatInterface extends JFrame {

	private JPanel contentPane;
	static JTextField SendBox = new JTextField();
	static JTextArea GetBox = new JTextArea();
	
	private String username;
	private int MySendPort;			// ������Ϣ�Ķ˿�
	private String toIP;			// ���͵��ĸ�IP
	private int toPort;				// ���͵��ĸ��˿ں�
	private int MyReceiverport;		// ������Ϣ�˿�
	private int MyFiletoport;
	private int MyFilegetport;
	
	UdpSender u1;
	UdpReceiver u2;
	UdpFileReceiver fr1;
	private JTextArea pathtext;

	
	public ChatInterface(String id) {
		setTitle("\u804A\u5929\u7CFB\u7EDF");	
		
		this.username=id;
	 	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 568, 538);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("\u53D1\u9001");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					u1.setReader(GetSendBoxText(username));
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(460, 412, 76, 66);
		contentPane.add(btnNewButton);
		
		
		SendBox.setBounds(14, 412, 432, 66);
		contentPane.add(SendBox);
		SendBox.setColumns(10);
		GetBox.setFont(new Font("����", Font.PLAIN, 16));
		GetBox.setEditable(false);
		
		GetBox.setBounds(14, 50, 522, 299);
		contentPane.add(GetBox);
		
		JButton btnNewButton_1 = new JButton("\u56FE\u7247");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String path=pathtext.getText();
				sendphoto(path);
			}
		});
		btnNewButton_1.setBounds(462, 362, 74, 37);
		contentPane.add(btnNewButton_1);
		
		pathtext = new JTextArea();
		pathtext.setBounds(14, 362, 432, 37);
		contentPane.add(pathtext);
		
		JTextField FriendName = new JTextField();
		FriendName.setEditable(false);
		FriendName.setFont(new Font("Monospaced", Font.BOLD, 16));
		FriendName.setText(username);
		FriendName.setHorizontalAlignment(JTextField.CENTER);
		FriendName.setBackground(UIManager.getColor("Button.background"));
		FriendName.setBounds(179, 13, 177, 29);
		contentPane.add(FriendName);
		
		init();
		chat();
	}
	
	
	public void init() {
		//������ݿ��и��û��Ķ˿ڵ���Ϣ
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); //����MYSQL JDBC�������� 	
		}catch(Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect=DriverManager.getConnection("jdbc:mysql://localhost/mysql","root","5426466");
			//mysqlΪ������������MySQL��������show tables��ʾ
			Statement stmt=connect.createStatement();
			
			ResultSet rs=stmt.executeQuery("select * from test");
			
			while(rs.next()) {
				if(rs.getString("Account").equals(username)) {
					this.MySendPort=rs.getInt("MySendPort");			//��ñ������ڷ��͵Ķ˿�
					this.MyReceiverport=rs.getInt("MyRecevierPort");	//���ص���Ϣ���ն˿�
					this.toIP=rs.getString("ToIP");						//���Ҫ���͵���IP��ַ
					this.toPort=rs.getInt("Toport");					//��÷��͵��Ķ˿ڵ�ַ
					this.MyFiletoport=rs.getInt("FileSendport");		//��÷��͵�ͼƬ�˿�
					this.MyFilegetport=rs.getInt("Filegetport");		//��ý���ͼƬ�Ķ˿�
					break;
				}
			}	
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void chat() {
		
		u1=new UdpSender(this.MySendPort,this.toIP,this.toPort);
		new Thread(u1).start();
		
		u2=new UdpReceiver(this.MyReceiverport,"İ����");
		new Thread(u2).start();
		
		
		///����ͼƬ���߳�
		fr1=new UdpFileReceiver(this.MyFilegetport,username);
		new Thread(fr1).start();
	}
	
	
	static public BufferedReader GetSendBoxText(String name) throws Exception {

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ		
		String Charset = (name + " " + df.format(new Date()) + "��"+SendBox.getText()+"\r\n"); 
		InputStream is = new ByteArrayInputStream( Charset.getBytes( ) );
		InputStreamReader reader = new InputStreamReader(is);
		BufferedReader ireader=new BufferedReader(reader);
		
		System.out.println("InputStreamReader:reader="+reader);
		System.out.println("BufferedReader:ireader="+ireader);
		String data = null;
		return ireader;
	}
	
	
	/*����ͼƬ*/
	public void sendphoto(String path) {
		UdpFileSender fs=new UdpFileSender(path,this.MyFiletoport);
		fs.run();	
	}
}
