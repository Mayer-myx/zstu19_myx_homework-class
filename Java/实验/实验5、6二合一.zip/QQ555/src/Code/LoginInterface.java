package Code;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.cj.conf.ConnectionUrlParser.Pair;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;


public class LoginInterface extends JFrame {

	private JPanel contentPane;
	private JTextField PasswordText;
	private JTextField IDText;

	static LoginInterface frame = new LoginInterface();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {	
					frame.setVisible(true);
					frame.setTitle("��¼����");	
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginInterface() {
		setTitle("\u767B\u5F55\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 395, 258);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		
		JButton loginButton = new JButton("\u767B\u5F55");
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   String id=IDText.getText();
				   String password=PasswordText.getText();

				   ArrayList< Pair<String,String>  > v=Sqlcheck();
				   				   
				   boolean flag=false;
				   
				   for(int i=0;i<v.size();i++) {

					   if( (v.get(i).left.equals(id)) && (v.get(i).right.equals(password)) ) {
						  System.out.println(v.get(i).left+" "+v.get(i).right);
						  flag=true;
					   }
				   }
				   
				   if(flag==true) {
					   JOptionPane.showMessageDialog(loginButton, "��¼�ɹ�");			   
					   ChatInterface ml=new ChatInterface(id);
					   frame.dispose();	   
					   ml.setVisible(true);
					   ml.setTitle("�������");
				   }
				   else {
					   JOptionPane.showConfirmDialog(loginButton, "��¼ʧ��");
				   }
			}
		});
		loginButton.setBounds(137, 156, 97, 23);
		contentPane.add(loginButton);
		

		
		JLabel IdLabel = new JLabel("\u8D26\u53F7\uFF1A");
		IdLabel.setBounds(58, 60, 58, 30);
		contentPane.add(IdLabel);
		
		JLabel PasswordLabel = new JLabel("\u5BC6\u7801\uFF1A");
		PasswordLabel.setBounds(58, 103, 58, 30);
		contentPane.add(PasswordLabel);
		
		PasswordText = new JTextField();
		PasswordText.setBounds(113, 103, 193, 30);
		contentPane.add(PasswordText);
		PasswordText.setColumns(10);
		
		IDText = new JTextField();
		IDText.setBounds(113, 60, 193, 30);
		contentPane.add(IDText);
		IDText.setColumns(10);
	}
	
	
	public ArrayList< Pair<String,String>  > Sqlcheck() {
		ArrayList< Pair<String,String>  > v=new ArrayList< Pair<String,String> >();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			Connection connect=DriverManager.getConnection("jdbc:mysql://localhost/mysql","root","5426466");
			Statement stmt=connect.createStatement();
			ResultSet rs=stmt.executeQuery("select * from test");
			while(rs.next()) {
				String user=rs.getString("Account");
				String password=rs.getString("Password");
				Pair<String,String> temp=new Pair<String,String>(user,password);
				v.add(temp);//���û����������vector
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return v;
	}

}
