package Code;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

///���Ͷ�
public class UdpFileSender implements Runnable {
	
	private String toIP ;
	private int filetoport; 				// �ļ����͵��ĸ��˿�
	volatile private String mFilePath; 		// �����͵��ļ�·��
	private DatagramSocket socket=null;
		
	public UdpFileSender(String filePath,int filetoport) {
		this.toIP="localhost";
		this.filetoport=filetoport;
		mFilePath = filePath;
		try {
			socket=new DatagramSocket();
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {				
		System.out.println("������������ļ���" + mFilePath);		
		File f=new File(mFilePath);		
		FileInputStream fin = null;
		
		try {
			fin = new FileInputStream(f);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
				
		byte[] datas = null;		
		datas = new byte[(int)f.length()];		
		try {
			fin.read(datas);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			fin.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		DatagramPacket packet=new DatagramPacket(datas,0,datas.length,new InetSocketAddress(this.toIP,this.filetoport));
		
		try {
			socket.send(packet);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("�ҷ����ļ���!");
		
		socket.close();			
	}
}



