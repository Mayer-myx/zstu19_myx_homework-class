package Code;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Random;


/*���ն�*/
public class UdpFileReceiver implements Runnable {
    
	private DatagramSocket socket=null;
	private int port;
	private String name;
	
	public UdpFileReceiver(int port,String name) {
		this.port=port;		//�ļ�������ն˿�	
		this.name=name;		//�����ļ�����
		try {
			socket=new DatagramSocket(port);	//���ĸ��˿ڽ���
		}catch(SocketException e) {
			e.printStackTrace();
		}	
	}
	
	public void run() {
		while(true) {
			byte[] container=new byte[30720];
			DatagramPacket packet=new DatagramPacket(container,0,container.length);
			try {
				socket.receive(packet);	//����ʽ���ܰ���
			} catch (IOException e) {
				e.printStackTrace();
			}

			System.out.println("��ʼ�����ļ�");
		
			Random random=new Random();
		
			///���յ����ļ�����Ŀ¼
			File file = new File("D:\\"+name+"datas"+"\\"+random.nextInt()+".jpg");
		
			FileOutputStream fos=null;
			try {
				fos = new FileOutputStream(file);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		
			byte[] data=new byte[30720];
			data=packet.getData();
		
			try {
				fos.write(data,0,data.length);
			} catch (IOException e) {	
				e.printStackTrace();
			}

			System.out.println("���ճɹ�");
			
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}
	
}