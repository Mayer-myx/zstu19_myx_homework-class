package Code;

import java.io.*;
import java.net.*;

///���Ͷ�
public class UdpSender implements Runnable {

	DatagramSocket socket=null;
	volatile BufferedReader reader=null;
	
	private int fromPort;		// ��������Ķ˿ں�
	private String toIP;		// ���͵��ĸ�IP
	private int toPort;			// ���͵�����Ķ˿ںš�
	
	public UdpSender(int fromPort,String toIP,int toPort) {
		this.fromPort=fromPort;
		this.toIP=toIP;
		this.toPort=toPort;
	
		try {
			socket=new DatagramSocket(fromPort);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	 
	public void setReader(BufferedReader reader) {
		 this.reader=reader;
	 }
					
	@Override
	public void run() {
		while(true) {
			try {	

				if(this.reader==null) continue;
				
				String data=null;
				data=this.reader.readLine();
		    	
				
				if(data==null) continue;
				System.out.println("������Ϣ�ɹ�");
				
				byte[] datas=data.getBytes();
				DatagramPacket packet=new DatagramPacket(datas,0,datas.length,new InetSocketAddress(this.toIP,this.toPort));
				
				byte[] d=packet.getData();
				String receiverData=new String(d,0,d.length);
				ChatInterface.GetBox.append(receiverData + "\n");
				ChatInterface.SendBox.setText("");
				
				socket.send(packet);
				System.out.println();
				
				if(datas.toString().equals("�ټ�") || datas.toString().equals("bye")) {
					break;
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		socket.close();
	}
	
}
