package Code;
import java.io.*;
import java.net.*;


///���ն�
public class UdpReceiver implements Runnable {
	
	private DatagramSocket socket=null;
	private int port;
	private String msgFrom;
	
	public UdpReceiver(int port,String msgFrom) {
		this.port = port;
		this.msgFrom = msgFrom;
		
		try {
			socket = new DatagramSocket(port);	//���ĸ��˿ڽ���
		}catch(SocketException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		
		while(true) {
			
			byte[] container = new byte[1024];
			DatagramPacket packet = new DatagramPacket(container,0,container.length);
			
			try {
				socket.receive(packet);		//����ʽ���ܰ���
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			byte[] data=packet.getData();
			String receiverData=new String(data,0,data.length);
			ChatInterface.GetBox.append(receiverData + "\n");
			ChatInterface.SendBox.setText("");
			
			if(receiverData.equals("�ټ�") || receiverData.equals("bye")) {
				break;	//�Ͽ�����
			}
		}
		socket.close();
	}
}
