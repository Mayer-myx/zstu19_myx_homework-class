public enum Direction {
	L,		//left
	U,  	//up
	R,  	//right
	D,  	//down
	STOP
}