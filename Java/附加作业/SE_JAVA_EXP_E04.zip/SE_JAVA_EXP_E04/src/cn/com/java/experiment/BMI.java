package cn.com.java.experiment;

public class BMI {

	private double weight;
	private double height;
	private Sex s;
	

	public BMI() {
		this.weight = 0;
		this.height = 0;
		this.s = Sex.WOMAN;
	}
	
	public BMI(double w, double h, Sex s) {
		this.weight =w;
		this.height = h;
		this.s = s;
	}
	
	
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}

	public Sex getS() {
		return s;
	}

	public void setS(Sex s) {
		this.s = s;
	}
	
	
	public double BMICount() {
		return (1.0) * weight / ( height * height );
	}
}
