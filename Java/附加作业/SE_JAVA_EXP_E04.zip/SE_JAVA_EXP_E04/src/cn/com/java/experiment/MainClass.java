package cn.com.java.experiment;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.UIManager;

public class MainClass extends JFrame {

	private JPanel contentPane;
	private JTextField textField_height;
	private JTextField textField_weight;
	private JTextArea showBMI;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainClass frame = new MainClass();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainClass() {
		setTitle("\u4F53\u91CD\u6307\u6570\u8BA1\u7B97\u5668");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 330);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_sex = new JLabel("\u6027\u522B");
		lblNewLabel_sex.setBounds(65, 82, 37, 18);
		contentPane.add(lblNewLabel_sex);
		
		JLabel lblNewLabel_height = new JLabel("\u8EAB\u9AD8\uFF08m\uFF09");
		lblNewLabel_height.setBounds(204, 57, 76, 18);
		contentPane.add(lblNewLabel_height);
		
		JLabel lblNewLabel_weight = new JLabel("\u4F53\u91CD\uFF08kg\uFF09");
		lblNewLabel_weight.setBounds(204, 107, 100, 18);
		contentPane.add(lblNewLabel_weight);
		
		textField_height = new JTextField();
		textField_height.setBounds(307, 54, 86, 24);
		contentPane.add(textField_height);
		textField_height.setColumns(10);
		
		textField_weight = new JTextField();
		textField_weight.setBounds(307, 104, 86, 24);
		contentPane.add(textField_weight);
		textField_weight.setColumns(10);
		
		
		HashMap<String, Sex> smap = new HashMap<>();
		smap.put("Ů", Sex.WOMAN);
		smap.put("��", Sex.MAN);
		
		
		//JPanel jp = new JPanel();
		JComboBox<String> SexBox = new JComboBox<>();
		SexBox.addItem("Ů");
		SexBox.addItem("��");
		SexBox.setBounds(103, 79, 59, 24);
		contentPane.add(SexBox);
		//jp.add(lblNewLabel_sex);
		//jp.add(SexBox);
		//contentPane.add(jp);
		//contentPane.setVisible(true);
		
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sex = SexBox.getSelectedItem().toString();
				double height = Double.parseDouble(textField_height.getText());
				double weight = Double.parseDouble(textField_weight.getText());
				Sex sss = smap.get(sex);
				BMI s=new BMI(weight, height, sss);
				double bm=s.BMICount();
				
				showBMI.setText("�Ա�" + s.getS() + "\n��������ָ��Ϊ" + bm);
				if(bm <= 18.4) {
					showBMI.setText(showBMI.getText() + "\n��������ƫ�ݡ�");
				}else if(bm <= 23.9) {
					showBMI.setText(showBMI.getText() + "\n��������������");
				}else if(bm <= 27.9) {
					showBMI.setText(showBMI.getText() + "\n�������Ĺ��ء�");
				}else {
					showBMI.setText(showBMI.getText() + "\n�������ĳ��ء�");
				}
			}
		});
		btnNewButton.setBounds(161, 153, 113, 27);
		contentPane.add(btnNewButton);
		
		showBMI = new JTextArea();
		showBMI.setBackground(UIManager.getColor("Button.background"));
		showBMI.setBounds(92, 193, 242, 77);
		contentPane.add(showBMI);
		showBMI.setColumns(10);
	}
}
