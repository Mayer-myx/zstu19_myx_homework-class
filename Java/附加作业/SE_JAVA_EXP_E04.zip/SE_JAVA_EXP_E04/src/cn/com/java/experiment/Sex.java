package cn.com.java.experiment;

public enum Sex {
	WOMAN,
	MAN
}
