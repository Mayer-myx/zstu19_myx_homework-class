package cn.com.java.experiment;

public class Employee {

	private int ID = 0;
	private String name = null;
	private Department department = null;
	private double salary = 0.0;
	
	
	public Employee() {}
	public Employee(int id, String n, Department d, double s) {
		this.ID = id;
		this.name = n;
		this.department = d;
		this.salary = s;
	}
	
	
	//�ṩgetter��setter����
	public int getID() {
		return ID;
	}
	
	public void setID(int iD) {
		ID = iD;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Department getDepartment() {
		return department;
	}
	
	public void setDepartment(Department department) {
		this.department = department;
	}
	public double getSalary() {
		return salary;
	}
	
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	//�ṩequals�������жϹ��ŵ��ظ���
	@Override
	public boolean equals(Object obj) {
		Employee e = (Employee) obj;
		if(e.getID() == this.getID())
			return true;
		else
			return false;
	}
	
	
	//toString���������Ա������
	public String toString() {
		return "���ţ�" + this.ID
				+ "\n������" + this.name 
				+ "\n���ţ�" + this.department 
				+ "\nнˮ��" + this.salary + "\n";
	}
}
