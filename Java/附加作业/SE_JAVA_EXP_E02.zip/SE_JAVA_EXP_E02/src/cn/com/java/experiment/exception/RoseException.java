package cn.com.java.experiment.exception;

public class RoseException extends Exception {
	 private String s;
	 public RoseException(String s) { this.s = s; }
	 
	 @Override
	 public String toString() { return s; }
}