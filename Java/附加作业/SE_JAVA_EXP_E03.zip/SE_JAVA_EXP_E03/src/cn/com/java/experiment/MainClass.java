package cn.com.java.experiment;

import cn.com.java.experiment.entity.Consumer;
import cn.com.java.experiment.entity.Producer;
import cn.com.java.experiment.entity.SharePool;

public class MainClass {

	public static void main(String[] args) {
		SharePool sp = new SharePool();
		
		for(int i = 1; i <= 5; i++)
			new Thread(new Producer(sp, i)).start();
		
		new Thread(new Consumer(sp)).start();
	}
}
