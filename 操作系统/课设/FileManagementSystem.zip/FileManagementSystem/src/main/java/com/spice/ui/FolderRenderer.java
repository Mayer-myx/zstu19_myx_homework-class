package com.spice.ui;
 
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

//自定义渲染器类，以描述节点的显示细节，此处的主要作用是渲染图片
public class FolderRenderer extends DefaultTreeCellRenderer {  
 
    private static FileSystemView fsView;
    private static final long serialVersionUID = 1L;
 
    //重写父类方法
    public Component getTreeCellRendererComponent(JTree tree, Object value,
 
        boolean sel, boolean expanded, boolean leaf, int row,

        boolean hasFocus) {
            //将当前树单元格的值设置为 value。如果 selected 为 true，则将单元格作为已选择的单元格进行绘制。
            //如果 expanded 为 true，则当前扩展该节点，如果 leaf 为 true，则该节点表示叶节点.
            //如果 hasFocus 为 true，则该节点当前拥有焦点。tree 是为其配置接收者的 JTree。
            //返回渲染器用来绘制值的 Component。

            fsView = FileSystemView.getFileSystemView();//获取FileSystemView的实例
            DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) value;//获取当前节点
            NodeData data = (NodeData) selectedNode.getUserObject();//取得节点的用户对象
            Icon icon = fsView.getSystemIcon(data.f);//Icon为图片
            
            setLeafIcon(icon);//用于显示叶节点的图标
            setOpenIcon(icon);//用于显示扩展的非叶节点的图标
            setClosedIcon(icon);//设置用于显示无扩展的非叶节点的图标

            return super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
 
    }
 
}