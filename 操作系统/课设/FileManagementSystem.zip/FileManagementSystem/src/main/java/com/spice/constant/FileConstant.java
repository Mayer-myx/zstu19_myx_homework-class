package com.spice.constant;

/**
 * 一些预定义好的常量
 */
public class FileConstant {

    /**
     * 文件名的大小，单位：B
     */
    public static final Integer FILE_NAME_SIZE = 36;
}
