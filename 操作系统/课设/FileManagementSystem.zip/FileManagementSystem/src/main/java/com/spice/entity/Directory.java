package com.spice.entity;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * 树形目录结构
 */
@Data
@Accessors(chain = true)
public class Directory implements Serializable {

    /**
     * 文件控制块
     */
    private FileControlBlock fileControlBlock;

    /**
     * 在树形目录结构中的位置
     */
    private Integer index;

    /**
     * 文件夹属性：子目录项集合
     */
    private List<Directory> childDirectory;

    /**
     * 父目录项的位置
     */
    private Integer parentIndex;

    public FileControlBlock getFileControlBlock() {
        return fileControlBlock;
    }

    public void setFileControlBlock(FileControlBlock fileControlBlock) {
        this.fileControlBlock = fileControlBlock;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public List<Directory> getChildDirectory() {
        return childDirectory;
    }

    public void setChildDirectory(List<Directory> childDirectory) {
        this.childDirectory = childDirectory;
    }

    public Integer getParentIndex() {
        return parentIndex;
    }

    public void setParentIndex(Integer parentIndex) {
        this.parentIndex = parentIndex;
    }
}
