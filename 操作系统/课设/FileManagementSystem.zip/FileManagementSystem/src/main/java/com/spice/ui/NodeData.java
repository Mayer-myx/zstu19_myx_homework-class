package com.spice.ui;
 
import java.io.File;

//文件节点类
public class NodeData{
 
    public File f;
    public String Name;

    public NodeData(File f, String Name) {
        this.f = f;
        this.Name = Name;
    }

    public String toString() {
        return Name;
    }

    public void ChangeString(String s) {
        Name = s;
    }

    public NodeData(File file) {
        this.f = file;
    }

}