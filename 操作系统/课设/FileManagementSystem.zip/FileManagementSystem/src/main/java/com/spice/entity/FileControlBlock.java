package com.spice.entity;

import com.spice.enums.ProtectType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 文件控制块
 */
@Data
@Accessors(chain = true)
public class FileControlBlock implements Serializable {

    /**
     * 是否是目录文件
     */
    private boolean isDirectory;

    /**
     * 文件名（包括了拓展名）
     */
    private String fileName;

    /**
     * 拓展名
     */
    private String suffix;

    /**
     * 起始盘块号
     */
    private Integer startBlock;

    /**
     * 所占用的盘块数
     * 文件大小 = 一个盘块的大小 * 所占用的盘块数
     */
    private Integer blockNum;

    /**
     * 文件属性：保护码列表
     */
    private List<ProtectType> protectTypeList;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 最后一次修改时间
     */
    private LocalDateTime updateTime;

    public boolean isDirectory() {
        return isDirectory;
    }

    public void setDirectory(boolean isDirectory) {
        this.isDirectory = isDirectory;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public Integer getStartBlock() {
        return startBlock;
    }

    public void setStartBlock(Integer startBlock) {
        this.startBlock = startBlock;
    }

    public Integer getBlockNum() {
        return blockNum;
    }

    public void setBlockNum(Integer blockNum) {
        this.blockNum = blockNum;
    }

    public List<ProtectType> getProtectTypeList() {
        return protectTypeList;
    }

    public void setProtectTypeList(List<ProtectType> protectTypeList) {
        this.protectTypeList = protectTypeList;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    
}
