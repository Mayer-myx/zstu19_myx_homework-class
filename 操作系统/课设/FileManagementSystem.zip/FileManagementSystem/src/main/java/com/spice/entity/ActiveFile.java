package com.spice.entity;

import lombok.Data;

import java.util.List;

/**
 * 当前打开的文件
 */
@Data
public class ActiveFile {

    /**
     * 文件控制块
     */
    private FileControlBlock fileControlBlock;

    /**
     * 文件记录
     */
    private List<Character> fileRecord;

    /**
     * 读指针
     */
    private Integer readPtr;

    /**
     * 写指针
     */
    private Integer writePtr;

    public FileControlBlock getFileControlBlock() {
        return fileControlBlock;
    }

    public void setFileControlBlock(FileControlBlock fileControlBlock) {
        this.fileControlBlock = fileControlBlock;
    }

    public List<Character> getFileRecord() {
        return fileRecord;
    }

    public void setFileRecord(List<Character> fileRecord) {
        this.fileRecord = fileRecord;
    }

    public Integer getReadPtr() {
        return readPtr;
    }

    public void setReadPtr(Integer readPtr) {
        this.readPtr = readPtr;
    }

    public Integer getWritePtr() {
        return writePtr;
    }

    public void setWritePtr(Integer writePtr) {
        this.writePtr = writePtr;
    }

    
}
