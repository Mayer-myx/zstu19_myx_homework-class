package com.spice.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * 连接数据库操作
 */
public class MySqlUtil {
    
    // MySQL 8.0 以下版本 - JDBC 驱动名及数据库 URL
    //static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    //static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB";
 
    // MySQL 8.0 以上版本 - JDBC 驱动名及数据库 URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; 
    static final String DB_URL = "jdbc:mysql://localhost:3306/myxtest?useSSL=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
 
    // 数据库的用户名与密码，需要根据自己的设置
    static final String USER = "root";
    static final String PASS = "5426466";

    static Map<String, String> file_user = new HashMap<>();
    static List<String> userList = new ArrayList<>();
    static List<String> pswList = new ArrayList<>();

    public static void connectAll(){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName(JDBC_DRIVER);
        
            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        
            // 执行查询
            System.out.println("实例化Statement对象...");
            stmt = conn.createStatement();
            String sql = "SELECT name, password, usergroup FROM myxtest.user";
            ResultSet rs = stmt.executeQuery(sql);
        
            // 展开结果集数据库
            while(rs.next()){
                // 通过字段检索
                String name  = rs.getString("name");
                String password = rs.getString("password");
                String usergroup = rs.getString("usergroup");
    
                // 存入用户数据 遍历使用
                userList.add(name);
                pswList.add(password);
                file_user.put(name, password);

                // 输出数据
                System.out.print("用户名: " + name);
                System.out.print(", 密码: " + password);
                System.out.println("");
            }

            // 完成后关闭
            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }

    // 插入新注册用户
    public static void insertData(String name, String psw){
        file_user.put(name, psw);
        userList.add(name);
        pswList.add(psw);

        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName(JDBC_DRIVER);
        
            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        
            // 执行插入
            System.out.println("实例化Statement对象...");
            stmt = conn.createStatement();
            String sql = "insert into myxtest.user(name,password,usergroup) values(?,?,'defaultsuer');";//数据库操作语句（插入）
            
            PreparedStatement pst = conn.prepareStatement(sql);//用来执行SQL语句，对sql语句进行预编译处理
            pst.setString(1, "nonono");
            pst.setString(2, "123");
            pst.executeUpdate();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }
        System.out.println("Goodbye!");
    }
}
