#include "Employee.h"
#include "Report.h"
#include "Date.h"
using namespace std;


int main() {
	system("color F1");//�ĸ���ɫ��blue on white

	Report r;
	r.insert(new Manager("200503"s, "Alex"s, 1, Date(2005, 6, 17), "����"s,
		map <int, int> { {1, 2000}, { 2, 1500 }, { 3, 3000 }, { 4, 2300 }, { 5, 3400 }, { 6, 2890 },
		{ 7, 3200 }, { 8, 2400 }, { 9, 2640 }, { 10, 2150 }, { 11, 4000 }, { 12, 3650 }}));
	r.insert(new Manager("200615"s, "Robert"s, 1, Date(2006, 8, 9), "����"s,
		map <int, int> { {1, 2100}, { 2, 1800 }, { 3, 2300 }, { 4, 3290 }, { 5, 2850 }, { 6, 3500 },
		{ 7, 2300 }, { 8, 1840 }, { 9, 2850 }, { 10, 2670 }, { 11, 3800 }, { 12, 4300 }}));
	r.insert(new Manager("200542"s, "Cindy"s, 0, Date(2005, 9, 1), "����"s,
		map <int, int> { {1, 2030}, { 2, 1350 }, { 3, 3050 }, { 4, 2100 }, { 5, 3200 }, { 6, 2350 },
		{ 7, 3500 }, { 8, 2000 }, { 9, 3400 }, { 10, 1850 }, { 11, 3600 }, { 12, 3860 }}));

	r.insert(new Technicist("200821"s, "Donald"s, 1, Date(2008, 6, 7), "������Ա"s));
	r.insert(new Technicist("200912"s, "Fred"s, 1, Date(2009, 8, 9), "������Ա"s));
	r.insert(new Technicist("200853"s, "Merri"s, 0, Date(2008, 9, 3), "������Ա"s));

	r.insert(new SalesPerson("201867"s, "Swift"s, 0, Date(2018, 10, 27), "������Ա"s,
		map <int, int> { {1, 12000}, { 2, 5000 }, { 3, 10600 }, { 4, 8900 }, { 5, 15000 }, { 6, 12890 },
		{ 7, 3200 }, { 8, 11050 }, { 9, 9040 }, { 10, 12150 }, { 11, 11600 }, { 12, 10850 }}));
	r.insert(new SalesPerson("201920"s, "Cruise"s, 1, Date(2019, 2, 12), "������Ա"s,
		map <int, int> { {1, 8600}, { 2, 9020 }, { 3, 10500 }, { 4, 10300 }, { 5, 10800 }, { 6, 18400 },
		{ 7, 3060 }, { 8, 2050 }, { 9, 1240 }, { 10, 1350 }, { 11, 1210 }, { 12, 2100 }}));
	r.insert(new SalesPerson("201912"s, "Hath"s, 0, Date(2019, 4, 21), "������Ա"s,
		map <int, int> { {1, 10050}, { 2, 7090 }, { 3, 9300 }, { 4, 10020 }, { 5, 20040 }, { 6, 20130 },
		{ 7, 20460 }, { 8, 19010 }, { 9, 12460 }, { 10, 13900 }, { 11, 12500 }, { 12, 16500 }}));


	int month;
	cout << "���������ɱ������·ݣ�";
	cin >> month;
	r.file_print(month);
	r.print(month);

	system("pause");
	return 0;
}