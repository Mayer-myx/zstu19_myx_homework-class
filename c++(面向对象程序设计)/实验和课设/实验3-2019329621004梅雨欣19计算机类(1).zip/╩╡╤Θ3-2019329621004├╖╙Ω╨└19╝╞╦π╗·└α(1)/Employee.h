#pragma once
#include <iostream>
#include <map>
#include <iomanip>
#include "Date.h"
using namespace std;

//�����ࣺԱ��
class Employee {
private:
    std::string ID;
    string name;
    int gender;//��1Ů0
    Date entry_date;//��ְ����
    string job;
    int salary{ 8000 };

public:
    Employee(string, string, int, Date, string);

    void set_ID(string);
    string get_ID();
    void set_name(string);
    string get_name();
    void set_gender(int);
    int get_gender();
    void set_entry_date(Date);
    Date get_entry_date();
    void set_job(string);
    string get_job();
    int get_salary();

    virtual int get_pay(int) = 0; //���������Ա����н
    friend ostream& operator << (ostream&, const Employee&);//����>>Ա����Ϣ
};

//-----------------------------------------------------------------
//����
class Manager : public Employee {
private:
    map <int, int> bonus;//�·�-����

public:
    Manager() = default;
    Manager(string, string, int, Date, string);
    Manager(string, string, int, Date, string, map<int, int>);

    int get_pay(int) override;
};

//-----------------------------------------------------------------
//������Ա
class Technicist : public Employee {
public:
    Technicist(string, string, int, Date, string);

    int get_pay(int) override;
};

//-----------------------------------------------------------------
//Ӫ����Ա
class SalesPerson : public Employee {
private:
    map <int, int> sale;//�·�-��������

public:
    SalesPerson(string, string, int, Date, string);
    SalesPerson(string, string, int, Date, string, map<int, int>);

    int get_pay(int) override;
};