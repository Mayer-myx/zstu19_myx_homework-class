#pragma once
#include<string>
using std::string;
using namespace std::string_literals;

class Date {
private:
    int year;
    int month;
    int day;
    int hour;
    int minute;

    static const int maxDay[2][13];
    friend std::istream& operator >> (std::istream&, Date);
    friend std::ostream& operator << (std::ostream&, Date);

public:
    Date();
    Date(int, int);
    Date(int, int, int);

    bool setYear(int year_);
    int getYear() const;
    bool setMon(int month_);
    int getMon() const;
    bool setDay(int day_);
    int getDay() const;
    bool setHour(int hour_);
    int getHour() const;
    bool setMinute(int minute_);
    int getMinute() const;


    void addDay(int);
    string toString(string);
};