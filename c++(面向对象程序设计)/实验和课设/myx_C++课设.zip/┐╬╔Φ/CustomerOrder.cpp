#include "CustomerOrder.h"
using namespace std;


CustomerOrder::CustomerOrder() : bill{ 0 }
{
    dish_num.clear();
}

void CustomerOrder::set_ID(int id)
{
    ID = id;
}

int CustomerOrder::get_ID()
{
    return ID;
}

void CustomerOrder::add_bill(double b)
{
    bill += b;
}

void CustomerOrder::set_bill(double b)
{
    bill = b;
}

double CustomerOrder::get_bill()
{
    return bill;
}

void CustomerOrder::set_dish_number(int dish_id, int num) 
{
    dish_num[dish_id] += num;
}

int CustomerOrder::get_dish_number(int dish_id)
{
    return dish_num[dish_id];
}


//����-----------------------------------------------------------------------------
TakeAway::TakeAway(Date _date) : time{ _date }
{
    bill = 0;
    dish_num.clear();
}

void TakeAway::set_phone(string _phonenumber) 
{
    phone = _phonenumber;
}

string TakeAway::get_phone()
{
    return phone;
}

void TakeAway::set_address(string add)
{
    address = add;
}

string TakeAway::get_address()
{
    return address;
}

Date TakeAway::get_time()
{
    return time;
}

void TakeAway::set_hour(int h)
{
    time.setHour(h);
}

void TakeAway::set_minute(int m)
{
    time.setMinute(m);
}


//��ʳ-----------------------------------------------------------------------------
EatIn::EatIn(int tnum) : table_number(tnum)
{
    bill = 0;
}

void EatIn::set_table_number(int n)
{
    table_number = n;
}

int EatIn::get_table_number()
{
    return table_number;
}