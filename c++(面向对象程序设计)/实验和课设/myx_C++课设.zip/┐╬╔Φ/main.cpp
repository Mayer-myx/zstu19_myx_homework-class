#include "Restaurant.h"
using namespace std;


int main()
{
    system("color F0");
    
    Restaurant restaurant;
    restaurant.sys();

    system("pause");
    return 0;
}