#include "Dish.h"
using namespace std;

Dish::Dish(int id, string na, double mon, double co) : dish_ID(id), name(na), money(mon), count(co) {}

void Dish::set_dish_ID(int id) {
	dish_ID = id;
}

int Dish::get_dish_ID() {
	return dish_ID;
}

void Dish::set_name(string na) {
	name = na;
}

string Dish::get_name() {
	return name;
}

void Dish::set_money(double m) {
	money = m;
}

double Dish::get_money() {
	return money;
}

//�����ۿ�
void Dish::set_count(double c) {
	system("mode con lines=8 cols=40");//����̨���ڴ�С
	HANDLE hwnd = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hwnd, (0 % 16) | (15 % 16 * 16));

	count = c;
}

double Dish::get_count() {
	return count;
}

ostream& operator << (ostream& os, const Dish& d) {
	os << "   " << d.dish_ID << "\t" << d.name << "\t" << d.money << "Ԫ" << "\t" << d.count << endl;
	return os;
}