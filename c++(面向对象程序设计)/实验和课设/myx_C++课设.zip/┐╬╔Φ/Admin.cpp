#include "Admin.h"
using namespace std;

string Admin::name{ "Admin" };
string Admin::password{ "Admin" };

Admin::Admin() : num_order{ 0 }, sum_sales{ 0 }, num_TakeAway{ 0 }, num_EatIn{ 0 }
{
    sum_dish_number.clear();
}

void Admin::set_num_order(int o)
{
    num_order = o;
}

void Admin::set_num_TakeAway(int y)
{
    num_TakeAway = y;
}

void Admin::set_num_EatIn(int g)
{
    num_EatIn = g;
}

void Admin::delete_num_order(int num)
{
    num_order -= num;
}

void Admin::delete_num_TakeAway(int num)
{
    num_TakeAway -= num;
}

void Admin::delete_num_EatIn(int num)
{
    num_EatIn -= num;
}

void Admin::add_sum_sales(double sales)
{
    sum_sales += sales;
}

void Admin::delete_sum_sales(double sales)
{
    sum_sales -= sales;
}

void Admin::add_sum_dish_number(int num, int c)
{
    sum_dish_number[num] += c;
}

int Admin::get_sum_dish_number(int num)
{
    return sum_dish_number[num];
}

double Admin::get_sum_sales()
{
    return sum_sales;
}

int Admin::get_num_TakeAway()
{
    return num_TakeAway;
}

int Admin::get_num_EatIn()
{
    return num_EatIn;
}

void Admin::set_password(string a) {
	password = a;
}

int Admin::get_num_order() {
    return num_order;
}

//��������Ա��¼
bool Admin::login(string name, string pass) {
    system("cls");
    system("mode con lines=12 cols=52");//����̨���ڴ�С
    HANDLE hwnd = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hwnd, (0 % 16) | (15 % 16 * 16));

    if (this->name == name && this->password == pass)     return 1;
 
    else        return 0;
}