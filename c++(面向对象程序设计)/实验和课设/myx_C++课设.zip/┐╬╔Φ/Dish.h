#pragma once
#include <iomanip>
#include <fstream>
#include <iostream>
#include <ctime> 
#include <cstdlib> 
#include <string>
#include <vector>
#include <conio.h>
#include <windows.h>
using namespace std;

class Dish {
private:
	int dish_ID{ 0 };//���
	string name;//����
	double money;//�۸�
	double count{ 1 };//�ۿ�

public:
	Dish() = default;
	Dish(int, string, double, double);

	void set_dish_ID(int);
	int get_dish_ID();
	void set_name(string);
	string get_name();
	void set_money(double);
	double get_money();
	void set_count(double);
	double get_count();

	friend ostream& operator << (ostream&, const Dish&);//�����Ʒ��Ϣ
};