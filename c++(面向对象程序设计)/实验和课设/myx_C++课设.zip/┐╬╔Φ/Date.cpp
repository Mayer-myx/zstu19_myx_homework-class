#include <iostream>
#include <ctime>
#include <cassert>
#include <string>
#include "Date.h"
#pragma warning(disable:4996)
using std::string;
using std::cout;
using std::endl;

const int Date::maxDay[2][13] = { {0,31,28,31,30,31,30,31,31,30,31,30,31},{0,31,29,31,30,31,30,31,31,30,31,30,31} };

Date::Date(int hour_, int minute_)
{
	time_t now;
	time(&now);
	struct tm* t_now;
	t_now = localtime(&now);
	year = t_now->tm_year + 1900;
	month = t_now->tm_mon + 1;
	day = t_now->tm_mday;
	if (hour_ >= 0 && hour_ < 24)
		if (minute_ >= 0 && minute_ < 60)
		{
			hour = hour_;
			minute = minute_;
		}
		else
			throw "minute is invalid";
	else
		throw "hour is invalid";
}

Date::Date()
{
	time_t now;
	time(&now);
	struct tm* t_now;
	t_now = localtime(&now);
	year = t_now->tm_year + 1900;
	month = t_now->tm_mon + 1;
	day = t_now->tm_mday;
	hour = t_now->tm_hour;
	minute = t_now->tm_min;
}

Date::Date(int y, int m, int d) {
	year = y; month = m; day = d;
	time_t now;
	time(&now);
	struct tm* t_now;
	t_now = localtime(&now);
	hour = t_now->tm_hour;
	minute = t_now->tm_min;
}
void Date::addDay(int n)
{
	day += n;
	if (day > maxDay[(year % 4 == 0 && year % 100 != 0) || year % 400 == 0][month]) {
		day %= maxDay[(year % 4 == 0 && year % 100 != 0) || year % 400 == 0][month];
		month++;
		if (month > 12) {
			year++;
			month %= 12;
		}
	}
}

string Date::toString(string format)
{
	if (format == "-"s)
		return std::to_string(year) + " - " + std::to_string(month) + " - " + std::to_string(day) + " " + std::to_string(hour) + ":" + std::to_string(minute);
	else if (format == "/"s)
		return std::to_string(year) + "��"s + std::to_string(month) + "��"s + std::to_string(day) + "��"s;
	else return "";
}

bool Date::setYear(int year_)
{
	if (year_ >= 1900 && year_ <= 2120) {
		year = year_;
		return true;
	}
	else return false;
}

int Date::getYear() const
{
	return year;
}

bool Date::setMon(int month_)
{
	if (month_ >= 1 && month_ <= 12)
	{
		month = month_;
		return true;
	}
	else return false;
}

int Date::getMon() const
{
	return month;
}

bool Date::setDay(int day_)
{
	if (day_ >= 1 && day_ <= maxDay[(year % 4 == 0 && year % 100 != 0) || year % 400 == 0][month])
	{
		day = day_;
		return true;
	}
	else return false;
}

int Date::getDay() const
{
	return day;
}

bool Date::setHour(int hour_)
{
	if (hour_ >= 0 && hour_ < 24)
	{
		hour = hour_;
		return true;
	}
	else
		return false;
}

int Date::getHour() const
{
	return hour;
}

bool Date::setMinute(int minute_)
{
	if (minute_ >= 0 && minute_ < 60)
	{
		minute = minute_;
		return true;
	}
	else
		return false;
}

int Date::getMinute() const
{
	return minute;
}

std::ostream& operator << (std::ostream& os, Date d) {
	os << d.toString("-");
	return os;
}

std::istream& operator >> (std::istream& is, Date d) {
	cout << "������������ �� �գ�";
	is >> d.year >> d.month >> d.day;
	return is;
}