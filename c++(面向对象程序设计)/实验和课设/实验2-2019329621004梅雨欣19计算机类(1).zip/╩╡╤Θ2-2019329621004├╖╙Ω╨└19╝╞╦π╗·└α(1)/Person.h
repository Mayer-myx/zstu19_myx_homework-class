#pragma once
#include <iostream>
using namespace std;

class Person {
private:
	double weight;
	int fromFloor{ 2 };
	int toFloor;

public:
	Person();
	Person(double, int);
	int getWeight();
	void setWeight(int);
	int getFromFloor();
	void setFromFloor(int);
	void setToFloor(int);
};