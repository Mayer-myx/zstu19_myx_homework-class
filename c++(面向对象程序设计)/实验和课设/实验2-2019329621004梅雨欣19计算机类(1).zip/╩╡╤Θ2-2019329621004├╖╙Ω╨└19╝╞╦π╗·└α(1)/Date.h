#pragma once
#include<string>
using std::string;
using namespace std::string_literals;

class Date {
public:
    Date(int, int, int);
    Date();
    void addDay(int);
    string toString(string);
    bool setYear(int year_);
    int getYear() const;
    bool setMon(int month_);
    int getMon() const;
    bool setDay(int day_);
    int getDay() const;

private:
    int year = 1900;
    int month = 1;
    int day = 1;
    static const int maxDay[2][13];
};