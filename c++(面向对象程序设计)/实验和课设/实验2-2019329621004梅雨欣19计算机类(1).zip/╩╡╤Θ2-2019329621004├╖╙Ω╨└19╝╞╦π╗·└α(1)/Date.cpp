#include <iostream>
#include <ctime>
#include <cassert>
#include <string>
#include "date.h"
#pragma warning(disable:4996)
using std::string;
using std::cout;
using std::endl;

const int Date::maxDay[2][13] = { {0,31,28,31,30,31,30,31,31,30,31,30,31},{0,31,29,31,30,31,30,31,31,30,31,30,31} };
Date::Date(int year_, int month_ = 1, int day_ = 1)
{
	if (year_ >= 1900 && year_ <= 9999)
		if (month_ >= 1 && month_ <= 12)
			if (day_ >= 1 && day_ <= maxDay[(year_ % 4 == 0 && year_ % 100 != 0) || year_ % 400 == 0][month_])
			{
				year = year_;
				month = month_;
				day = day_;
			}
			else throw "day is invalid";
		else throw "month is invalid!";
	else throw "year is invalid!";
}

Date::Date()
{
	time_t now;
	time(&now);
	struct tm* t_now;
	t_now = localtime(&now);
	year = t_now->tm_year + 1900;
	month = t_now->tm_mon + 1;
	day = t_now->tm_mday;
}
void Date::addDay(int n)
{
	day += n;
	if (day > maxDay[(year % 4 == 0 && year % 100 != 0) || year % 400 == 0][month]) {
		day %= maxDay[(year % 4 == 0 && year % 100 != 0) || year % 400 == 0][month];
		month++;
		if (month > 12) {
			year++;
			month %= 12;
		}
	}
}
string Date::toString(string format)
{
	if (format == "yyyy-MM-dd"s)
		return std::to_string(year) + "-" + std::to_string(month) + "-" + std::to_string(day);
	else if (format == "yyyy/MM/dd"s)
		return std::to_string(year) + "��"s + std::to_string(month) + "��"s + std::to_string(day) + "��"s;
	else return "";
}
bool Date::setYear(int year_)
{
	if (year_ >= 1900 && year_ <= 2120) {
		year = year_;
		return true;
	}
	else return false;
}
int Date::getYear() const
{
	return year;
}
bool Date::setMon(int month_)
{
	if (month_ >= 1 && month_ <= 12)
	{
		month = month_;
		return true;
	}
	else return false;
}
int Date::getMon() const
{
	return month;
}
bool Date::setDay(int day_)
{
	if (day_ >= 1 && day_ <= maxDay[(year % 4 == 0 && year % 100 != 0) || year % 400 == 0][month])
	{
		day = day_;
		return true;
	}
	else return false;
}
int Date::getDay() const
{
	return day;
}