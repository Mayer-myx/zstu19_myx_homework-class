#include "Person.h"


Person::Person() {}

Person::Person(double a, int b) : weight(a), fromFloor(b) {}

int Person::getWeight() {
	return weight;
}

int Person::getFromFloor() {
	return fromFloor;
}

void Person::setToFloor(int a) {
	toFloor = a;
}

void Person::setFromFloor(int a) {
	fromFloor = a;
}

void Person::setWeight(int a) {
	weight = a;
}