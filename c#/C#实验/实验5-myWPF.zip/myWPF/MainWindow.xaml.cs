﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;


namespace myWPF
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isSaved;
        private string title
        {
            set { Title = value; }
            get { return Title; }
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            isSaved = false;
            TextRange range;
            range = new TextRange(TextBox.Document.ContentStart, TextBox.Document.ContentEnd);
            range.Text = "";
        }

        private void OpenCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.DefaultExt = "*.txt";
            dlg.Filter = "Text Files (*.txt)|*.txt";
            bool? result = dlg.ShowDialog();
            if (result == true)
            {
                string fileName = dlg.FileName;
                TextRange range;
                FileStream fStream;
                if (File.Exists(fileName))
                {
                    title = fileName;
                    range = new TextRange(TextBox.Document.ContentStart, TextBox.Document.ContentEnd);
                    fStream = new FileStream(fileName, FileMode.OpenOrCreate);
                    range.Load(fStream, DataFormats.XamlPackage);
                    fStream.Close();
                }
            }

        }

        private void SaveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (isSaved) return;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "文本文件|*.txt|所有文件|*.*";
            saveFileDialog.FilterIndex = 0;
            bool? result = saveFileDialog.ShowDialog();
            if (result == true)
            {
                string strFile = saveFileDialog.FileName;
                TextRange range;
                title = strFile;
                FileStream fStream;
                range = new TextRange(TextBox.Document.ContentStart, TextBox.Document.ContentEnd);
                fStream = new FileStream(strFile, FileMode.Create);
                range.Save(fStream, DataFormats.XamlPackage);
                fStream.Close();

                isSaved = true;
                StatusBar.Text = "保存到" + strFile;
            }
        }

        private void PrintCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            PrintDialog pd = new PrintDialog();
            if ((pd.ShowDialog() == true))
            {
                pd.PrintVisual(TextBox as Visual, "Printing as visual");
                pd.PrintDocument((((IDocumentPaginatorSource)TextBox.Document).DocumentPaginator), "Printing as paginator");
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            isSaved = false;
        }

        private void LineCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
        }

        private void FontSelectCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
        }
    }
}
