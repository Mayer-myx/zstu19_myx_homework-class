﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Data;
using System.Data.OleDb;


namespace myWPF
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        static string mdbFile = "D:\\NorthWindDataBase\\Northwind.mdb";
        static OleDbConnection connection;
        static OleDbDataAdapter adapter;
        static DataSet dataset;

        public MainWindow()
        {
            InitializeComponent();

            DataContext = this;
        }

        public void GetAllGuests()
        {
            DataView dataView = GetSelectedGuest();
            datagrid.ItemsSource = dataView;
            //gridData.ItemsSource = dataset.Tables["Customers"].DefaultView;
        }

        public void GetAllColumns()
        {
            var command = connection.CreateCommand();
            command.CommandText = "select * from 客户";

            OleDbDataReader reader = command.ExecuteReader();
            reader.Read();
            List<string> columns = new List<string>();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                columns.Add(reader.GetName(i));
            }
            comboColumn.ItemsSource = columns;
            reader.Close();
        }

        public DataView GetSelectedGuest()
        {
            var command = connection.CreateCommand();
            command.CommandText = "select * from 客户";
            Console.WriteLine(status.Content);
            if (comboColumn.SelectedIndex != -1 && comboRow.SelectedIndex != -1)
            {
                command.CommandText = "select * from 客户 where " + comboColumn.Text + "='" + comboRow.Text + "'";
            }
            status.Content = command.CommandText;
            dataset = new DataSet();
            DataTable dt1 = new DataTable("Scene");
            dataset.Tables.Add(dt1);
            adapter = new OleDbDataAdapter(command);
            adapter.Fill(dt1);
            return dt1.DefaultView;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string connString = @" Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + mdbFile;
            connection = new OleDbConnection(connString);
            //补全
            try
            {
                connection.Open();
                Console.WriteLine($"数据库连接成功\n{mdbFile} is {connection.State}");
                GetAllGuests();
                GetAllColumns();
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.Message);
                connection.Close();
            }
        }

        private void comboColumn_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboColumn.SelectedIndex == -1)
            {
                comboRow.ItemsSource = null;
                return;
            }

            var command = connection.CreateCommand();
            command.CommandText = "select * from 客户";
            OleDbDataReader reader = command.ExecuteReader();
            SortedSet<string> columns = new SortedSet<string>();
            while (reader.Read())
            {
                columns.Add(reader[comboColumn.SelectedIndex].ToString());
            }
            comboRow.ItemsSource = columns;
            reader.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            GetAllGuests();
        }

        private void datagrid_MouseUp(object sender, MouseButtonEventArgs e)
        {
            DataRowView data = datagrid.SelectedItem as DataRowView;
            if (data == null)
                return;
            string id = data["客户ID"].ToString();
            var command = connection.CreateCommand();
            command.CommandText = "select count(*) from 订单 where 客户ID='" + id + "'";
            int count = (int)command.ExecuteScalar();
            status.Content = data["客户ID"] + "客户共有" + count + "个订单";
            Console.WriteLine("记录总数：" + count);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            comboColumn.SelectedIndex = -1;
            GetAllGuests();
        }
    }
}
