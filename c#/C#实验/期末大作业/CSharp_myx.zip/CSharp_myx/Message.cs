﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace CSharp_myx
{
    class Message
    {
        private string mName;
        private string time;
        private string con;

        public string MName
        {
            get { return mName; }
            set
            {
                if (value == mName) return;
                mName = value;
            }
        }
        public string Time 
        {
            get => System.DateTime.Now.ToString("g"); 
            set 
            {
                if (value == System.DateTime.Now.ToString("g")) return;
                time = value;
            }
        }
        public string Con
        {
            get { return con; }
            set
            {
                if (value == con) return;
                con = value;
            }
        }

        override public string ToString()
        {
            return "" + MName + "\t" + Time + "\n" + Con + "\n";
        }
    }
}
