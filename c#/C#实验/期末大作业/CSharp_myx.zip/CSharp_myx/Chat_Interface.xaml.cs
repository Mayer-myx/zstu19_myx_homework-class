﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Net;
using System.Net.Sockets;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Threading;

namespace CSharp_myx
{
    /// <summary>
    /// Chat.xaml 的交互逻辑
    /// </summary>
    public partial class Chat : Window
    {
        List<Message> mesList;
        Person friend = new Person("Friend", "阿巴阿巴", 1);

        public Chat()
        {
            InitializeComponent();

            mesList = new List<Message>()
            {
                //初始化内容
                new Message() { MName = friend.Name, Con = "在吗？" },
                new Message() { MName = friend.Name, Con = "在吗？" },
            };


            foreach (var i in mesList)
                AddText(new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF96516A")), i.ToString());
        }

        private void AddText(Brush brush, string txt)
        {
            var p = new Paragraph();
            var r = new Run(txt);
            p.Inlines.Add(r);
            p.Foreground = brush;   //设置字体颜色
            chat_RTB_show.Document.Blocks.Add(p);
        }

        //发送按钮
        private void chat_Btn_send_Click(object sender, RoutedEventArgs e)
        {
            TextRange textRange = new TextRange(chat_RTB_message.Document.ContentStart, chat_RTB_message.Document.ContentEnd);
            string message = textRange.Text;

            if (message == null)
            {
                MessageBox.Show("消息不能为空");
                return;
            }
            chat_RTB_message.Document.Blocks.Clear();
            Message m = new Message() { MName = "me", Con = message };
            Brush b = new SolidColorBrush(Color.FromRgb(255, 108, 116));
            AddText(b, m.ToString());

            Message re = new Message() { MName = friend.Name, Con = reply(message)};
            AddText(new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF96516A")), re.ToString());
        }

        //关闭按钮
        private void chat_Btn_exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void show_change(object sender, RoutedEventArgs e)
        {
            //让文本框获取焦点  
            chat_RTB_show.Focus();
            //设置光标的位置到文本尾
            chat_RTB_show.ScrollToEnd();
        }

        //右键鼠标菜单_复制
        private void Mouse_Right_Click_copy(object sender, RoutedEventArgs e)
        {
            Clipboard.SetData(DataFormats.Rtf, chat_RTB_show.Selection);
        }

        //右键鼠标菜单_全选
        private void Mouse_Right_Click_all(object sender, RoutedEventArgs e)
        {
            chat_RTB_show.Focus();      //设置焦点定位到当前活动的RichTextBox
            chat_RTB_show.SelectAll();
        }

        //右键鼠标菜单_清除
        private void Mouse_Right_Click_clear(object sender, RoutedEventArgs e)
        {
            chat_RTB_show.Document.Blocks.Clear();
        }

        //对面的回答
        private string reply(string m)
        { 
            
            if (m[0] >= '0' && m[0] <= '9')
                return "我知道答案！是等于" + new DataTable().Compute(m, "false").ToString();
            else if (m.Contains("你好"))
                return "你好";
            else if (m.Contains("多少"))
                return "你猜猜看呀";
            else if (m.Contains("几岁"))
                return "永远18岁！";
            else
                return m + "啊? 我不知道呀，以后再问我吧qwq";
        }
    }
}
