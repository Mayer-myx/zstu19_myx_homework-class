﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CSharp_myx
{
    /// <summary>
    /// Main_Interface.xaml 的交互逻辑
    /// </summary>
    public partial class Main_Interface : Window
    {
        List<Person> perList;

        public Main_Interface()
        {
            InitializeComponent();

            perList = new List<Person>()
            {
                new Person("小橙", "阳光总在风雨后", 1),
                new Person("小黄", "人生碌碌，竞短论长，却不道荣枯有数，得失难量。", 2),
                new Person("小绿", "生存本身是一种徒劳。", 3),
                new Person("小青", "my soul", 4),
                new Person("小蓝", "Never say die.", 5),
                new Person("小紫", "我的肩上是风，风上是闪烁的星群。", 6),
                new Person("班长", "There is more come.", 7),
                new Person("学委", "我的秋千一次次在空中散开我的额心碰到太阳。", 8),
                new Person("小红", "夏天到了", 9)
            };
            this.main_LB_conPerson.ItemsSource = perList;
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }

        private void ListBoxItem_MouseDoubleClick(object sender, RoutedEventArgs e)
        {
            //TextBlock tn = this.main_LB_conPerson.ItemTemplate.FindName("itemName", this.main_LB_conPerson) as TextBlock;
            //TextBlock tw = this.main_LB_conPerson.ItemTemplate.FindName("itemWords", this.main_LB_conPerson) as TextBlock;
            //ListBox listView = ItemsControl.ItemsControlFromItemContainer(myListBoxItem) as ListBox;
            //c.name = perList[0].name;
            //c.words = perList[0].words;
            //c.name = tn.Text;
            //c.words = tw.Text;
            Chat c = new Chat();
            MessageBox.Show($"ListBoxItem被双击");

            c.Show();
        }
    }
}
