﻿using Microsoft.Data.Sqlite;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Threading;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CSharp_myx
{
    /// <summary>
    /// Login_Interface.xaml 的交互逻辑
    /// </summary>
    public partial class Login_interface : Window
    {
        public Login_interface()
        {
            InitializeComponent();
        }

        //密码md5加密
        public string getMD5(string s)
        {
            MD5 mD5 = MD5.Create();
            byte[] buffer = Encoding.GetEncoding("gbk").GetBytes(s);
            byte[] Md5Buffer = mD5.ComputeHash(buffer);
            string str = "";
            for (int i = 0; i < Md5Buffer.Length; i++)
            {
                str = str + Md5Buffer[i].ToString();
            }
            return str;
        }

        private void Button_login_Click(object sender, RoutedEventArgs e)
        {
            //登录验证
            SqliteCommand cmd = new SqliteCommand();
            cmd.CommandText = "select * from userMessage where username =" + login_TB_account.Text;
            if (login_TB_account.Text.Equals("1677") && login_TB_password.Text.Equals("111"))
            {
                login_Button_login.Content = "登录中…";
                BrushConverter conv = new BrushConverter();
                login_Button_login.Background = conv.ConvertFromInvariantString("#66ccff") as Brush;
                Main_Interface m = new Main_Interface();
                m.Show();
                this.Close();
            }
            else
            {
                login_TB_password.Text = "";
            }
        }
    }
}
