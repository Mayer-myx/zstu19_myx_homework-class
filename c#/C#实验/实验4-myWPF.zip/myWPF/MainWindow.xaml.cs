﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace myWPF
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        Dictionary<string, double> length = new Dictionary<string, double> { { "m(米)", 1 }, { "cm(厘米)", 0.01 }, { "mm(毫米)", 0.001 }, { "英寸", 0.0254 }, { "英尺", 0.3048 } ,{ "英里", 1609.344 } };
        Dictionary<string, double> mass = new Dictionary<string, double>{ {"g(克)", 1 },  {"斤", 500 }, {"kg(千克)", 1000 }};
        List<string> items = new List<string>() { "摄氏度℃", "华氏度℉" };

        public MainWindow()
        {
            InitializeComponent();
        }

        private void lstSource_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBox listBox1 = sender as ListBox;
            string txt = listBox1.SelectedItem as string;
            lstText.Text = txt;
            lstvalText.Text = tndvalText.Text = "";
        }

        private void tndSource_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBox listBox2 = sender as ListBox;
            string txt = listBox2.SelectedItem as string;
            tndText.Text = txt;
            lstvalText.Text = tndvalText.Text = "";
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            ComboBoxItem item = cb.SelectedItem as ComboBoxItem;
            string selected = item.Content.ToString();
            if (selected == "长度")
            {
                lstSource.ItemsSource = length.Keys;
                tndSource.ItemsSource = length.Keys;
            }
            else if (selected == "质量")
            {
                lstSource.ItemsSource = mass.Keys;
                tndSource.ItemsSource = mass.Keys;
            }
            else if (selected == "温度")
            {
                lstSource.ItemsSource = items;
                tndSource.ItemsSource = items;
            }
            lstvalText.Text = tndvalText.Text = "";
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (lstSource == null || tndSource == null)
                return;
            if (errText != null)
                errText.Text = "";
            if (lstvalText.Text == "" || lstSource.SelectedIndex == -1 || tndSource.SelectedIndex == -1)
            {
                tndvalText.Text = "0";
                return;
            }
            try
            {
                tndvalText.Text = "0";
                double a = double.Parse(lstvalText.Text);
                if (comboTypes.SelectedIndex == 0)
                {
                    tndvalText.Text = (a * length[lstText.Text] / length[tndText.Text]).ToString();
                }
                else if (comboTypes.SelectedIndex == 1)
                {
                    tndvalText.Text = (a * mass[lstText.Text] / mass[tndText.Text]).ToString();
                }
                else if (comboTypes.SelectedIndex == 2)
                {
                    if (lstSource.SelectedIndex == 0)
                    {
                        tndvalText.Text = (a * 1.8 + 32).ToString();
                    }
                    else
                    {
                        tndvalText.Text = ((a - 32) / 1.8).ToString();
                    }
                }
            }
            catch (FormatException fe)
            {
                errText.Text = "数据格式错误:" + fe.Message;
            }
            catch (KeyNotFoundException kfe)
            {
                errText.Text = "单位错误：" + kfe.Message;
            }
        }
    }
}
